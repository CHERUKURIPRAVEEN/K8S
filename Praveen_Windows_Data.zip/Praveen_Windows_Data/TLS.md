* Need for SSL/TLS 
* Cryptography vs Encryption 
* Hashing in Cryptography 
* Encryption vs Hashing
* Symmetric vs Asymmetric Encryption
* HTTPS Protocol
* SSL/TLS Handshake
* Client vs Server Certificates 
* Certificate Authority (CA) 
* Public Key Infrastructure(PKI) 
* SSL Certificate types 
* Self Signed Certificates U
* sing OpenSSL Utility 
* Generating CSR
* Subject Alternative Name(SAN) 
* Create Root CA Cert and Key 
* X.509 Certificates
* Decoding Certificates & CSR

> **Whenever you send or receive information on the Internet, it passes through a network of multiple computers to reach the destination.**
> **Historically, any of these computers could read your data, because it was not encrypted.**

> **Much of this data is quite sensitive and valuable to hackers.**
> **It can include private communications that are not end-to-end encrypted, financial information, and even login credentials for web applications.**

#### We encounter three significant security issues while sending information online:
1. Can we verify the identity of the person we speak with?
2. How can we be certain that the data they gave wasn't altered? 
3. How can we stop unauthorized users from accessing and viewing the data?

* **To protect sensitive data, security experts developed a new standard protocol to send and receive Internet traffic: Transport Layer Security (TLS).**
* **This was preceded by Secure Sockets Layer (SSL).**

### What is cryptography?
> **TLS**

**Cryptography**

- Cryptography is the art of encrypting information in a way that unintended recipients cannot understand.
- In cryptography, an original human-readable message, known as plaintext, is transformed by an algorithm, or series of mathematical operations, into unreadable text called ciphertext Ciphertext is very hard to decode.
- The prefix *crypt* means *hidden* and suffix *graphy* means *writing*.

**Encryption vs cryptography**

- **Cryptography** is study of methods like encryption. Its main objective is to provide methods to secure and protect information and communications using encryption and related techniques.
- **Encryption** is the way(process) to encrypt and decrypt data. It is considered as principal application of cryptography.