### Docker Logs

Create file under below path with name **daemon.json**
```
vi /etc/docker/daemon.json
```
Once file created add below data
```
{
  "metrics-addr" : "0.0.0.0:9323",
  "experimental" : true
}
```
After that **reload** the the `docker service`.
