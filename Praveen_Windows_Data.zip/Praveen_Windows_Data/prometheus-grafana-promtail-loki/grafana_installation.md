## Grafana Installtion
#### Installing on linux server
* Install Grafana from apt repo
```
sudo apt-get install -y adduser libfontconfig1
wget https://dl.grafana.com/enterprise/release/grafana-enterprise_10.0.0_amd64.deb
sudo dpkg -i grafana-enterprise_10.0.0_amd64.deb
```
* Once service file add use below command to start grafana
```
systemctl start grafana.service
systemctl status grafana.service
```

#### Docker (Run as a docker container)
* Download latest version of [Docker](https://docs.docker.com/)
* After download the grafana docker image
```
docker pull grafana/grafana
```
* After create volume 
```
docker volume create grafana_config
docker volume create grafana_data 
docker volume create grafana_logs
```
* After that run below command 
```
docker run -d --name grafana -p 3000:3000 -v grafana_config:/etc/grafana -v grafana_data:/var/lib/grafana -v grafana_logs:/var/log/grafana grafana/grafana
```
Once conatiner up and running, check grafana is running or not 
```
<PUBLICIPADDRESS:PORT>
ex: 3.80.184.117:3000
```
* default username id and password
```
username : admin
password : admin
```