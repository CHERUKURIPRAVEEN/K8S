## Prometheus Installtion
#### Install as a service on linux
* Download the Prometheus latest package [Prometheous](https://prometheus.io/download/#prometheus)
* Untar it
```
tar xvfz prometheus-*.tar.gz
mv prometheus-* /opt/prometheus
cd /opt/prometheus
```
* Create a file with name `prometheus.yml` under /opt/prometheus and add below configurations

```
global:
  scrape_interval:     15s # By default, scrape targets every 15 seconds.

  # Attach these labels to any time series or alerts when communicating with
  # external systems (federation, remote storage, Alertmanager).
  external_labels:
    monitor: 'codelab-monitor'

# A scrape configuration containing exactly one endpoint to scrape:
# Here it's Prometheus itself.
scrape_configs:
  # The job name is added as a label `job=<job_name>` to any timeseries scraped from this config.
  - job_name: 'prometheus'

    # Override the global default and scrape targets from this job every 5 seconds.
    scrape_interval: 5s

    static_configs:
      - targets: ['localhost:9090']
```
* Starting Prometheus as a service
* Create a file prometheus.service under `/etc/systmd/system/`

```
[Unit]
Description=Prometheus Service
After=network.target

[Service]
Type=simple
ExecStart=/opt/prometheus/prometheus --config.file=/opt/prometheus/prometheus.yml

[Install]
WantedBy=multi-user.target
```
* Once service file add use below command to start prometheus
```
systemctl start prometheus.service
```

#### Docker (Run as a docker container)
* Download latest version of [Docker](https://docs.docker.com/)
* After download the prometheus docker image
```
docker pull prom/prometheus
```
* After create volume 
```
docker volume create prometheus_config
```
* Create a file with name `prometheus.yml` under /opt/prometheus and add below configurations
```
global:
  scrape_interval:     15s # By default, scrape targets every 15 seconds.

  # Attach these labels to any time series or alerts when communicating with
  # external systems (federation, remote storage, Alertmanager).
  external_labels:
    monitor: 'codelab-monitor'

# A scrape configuration containing exactly one endpoint to scrape:
# Here it's Prometheus itself.
scrape_configs:
  # The job name is added as a label `job=<job_name>` to any timeseries scraped from this config.
  - job_name: 'prometheus'

    # Override the global default and scrape targets from this job every 5 seconds.
    scrape_interval: 5s

    static_configs:
      - targets: ['localhost:9090']
```
* Now copy the prometheus configuration file to new volume
```
cp /opt/prometheus/prometheus.yml /var/lib/docker/volumes/prometheus_config/_data
```
* After that run below command 
```
docker run -d --name prometheus -p 9090:9090 -v prometheus_config:/etc/prometheus/ prom/prometheus
```
* Once conatiner up and running, check prometheous is running or not 
```
<PUBLICIPADDRESS:PORT>
ex: 3.80.184.117:9090
```