## **Linux bash shell Scripting**

> Shell is the linux commands line interpreter, shell executes the commands/scripts.
> There are different types of shells to execute commands/scripts in unix/linux environment.

* Using below command to find out valid login shells
```
cat /etc/shells
```
Output

```
# /etc/shells: valid login shells
/bin/sh
/bin/bash
/usr/bin/bash
/bin/rbash
/usr/bin/rbash
/bin/dash
/usr/bin/dash
/usr/bin/tmux
/usr/bin/screen
```

* To Know the current **SHELL**
```
echo $SHELL
```
* The most advanced and popular shell is **bash**
