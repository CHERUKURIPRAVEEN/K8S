## Commands Usage and Options

#### echo
```sh
echo [flag] [arguments]
echo -n (Do not append a newline or trailing newline is suppressed)
echo -e (enable interpreation of the following backslash escape/escaped characters)
echo -E (explicity suppress interpretation of backslash escape) `it is default`
```
