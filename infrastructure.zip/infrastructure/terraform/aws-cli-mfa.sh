#!/usr/bin/env bash
#
# Dependencies:
#   brew install jq
#
# Setup:
#   chmod +x ./aws-cli-mfa.sh
#
# Execute:
#   source ./aws-cli-mfa.sh AWS_ACCOUNT_ID MFA_TOKEN AWS_PROFILE USER
#
# Description:
#   Makes assuming an AWS IAM role (+ exporting new temp keys) easier
if ! [[ $4 ]]; then
	username="dspitsin"
else
	username="$4"
fi

echo "Username: $username" 
echo "Account: $1"
echo "MFA Token: $2"
echo "AWS Profile: $3"

if [[ "$1" == "unset" ]]; then
  unset AWS_SESSION_TOKEN
  unset AWS_ACCESS_KEY_ID
  unset AWS_SECRET_ACCESS_KEY
else
  unset AWS_SESSION_TOKEN
  unset AWS_ACCESS_KEY_ID
  unset AWS_SECRET_ACCESS_KEY

  temp_role=$(aws sts get-session-token --serial-number arn:aws:iam::$1:mfa/$username --token-code $2 --profile $3)

  export AWS_ACCESS_KEY_ID=$(echo $temp_role | jq .Credentials.AccessKeyId | xargs)
  export AWS_SECRET_ACCESS_KEY=$(echo $temp_role | jq .Credentials.SecretAccessKey | xargs)
  export AWS_SESSION_TOKEN=$(echo $temp_role | jq .Credentials.SessionToken | xargs)

  env | grep -i AWS_
fi


