#!/bin/bash
#set -x

CURENT_LOCATION="$(pwd)"
echo "${CRENT_LOCATION}"
return_shlib() {
    if [ -f "$1/tf.shlib" ];then
      echo "$1"
    else
      cd $1/../
      return_shlib "$(pwd)"
    fi
}

SHLIBPATH="$(return_shlib  ${CURENT_LOCATION})"
echo "SHLIBPATH $SHLIBPATH"

#SHLIBPATH=$(dirname "${BASH_SOURCE[0]}")
#SHLIBPATH="$(cd -P ${SHLIBPATH} && pwd -P)"
source ${SHLIBPATH}/tf.shlib
unset BRANCH
unset GITBRANCH
unset ENVIRONMENT
unset OVERRIDE
unset FORCE
unset S3LOGBUCKET
unset S3BUCKETREGION
unset REGION
unset PROJECT
unset ACTION
unset AWSPROFILE
unset VARFILE
unset ARGS
unset arg
unset argKey
unset argVal
unset skipNext
unset nextArg
#echo "${BASH_SOURCE[0]} $@"
showUsage() {
  echo "Usage:

  $0 {a|e|o|b|p|j|r|l|h|v|f} [ARG...]

Options:
	Terraform Automation ver.1.0.0

  -a, --action ARG
    Action (apply/destroy) for terraform command. Used only if -l, --s3_log_bucket is set or -f|--force.
    Default: no any action with terraform.

  -e, --environment ARG
    Environment. This environment used for determine configuration file in in the configuration/<env>.cfg.
    Ex: dev/qa/stage/prd
    Default: dev

  -o, --override ARG
    Override environment. This will override environment used for determine terraform backend configuration file.
    Ex: dev/qa/stage/prd
    Default: null

  -p, --profile, --aws_profile ARG
    AWS PROFILE name from ~/.aws/credentials file. 0 - meaning to not use of .aws/credentials file.
    Default: takes from configuration/<env>.cfg.

  -h, --help
    Help for this script.

  -j, --project ARG
    Project Name.
    Default: takes from configuration/<env>.cfg.

  -l, --s3_log_bucket ARG
    S3 bucket name for logging "terraform plan"

  -b, --s3_bucket_region ARG
    AWS Region Location for Terraform tfstates S3 bucket
    Default: takes from configuration/<env>.cfg.

  -r, --region ARG
    AWS Region Name
    Default: takes from configuration/<env>.cfg.

  -v, ---var, --var-file ARG
    Terraform -var-file location.
    Default: takes from variables/<env>.tfvars.

  -f, --force
    Force apply or destroy with terraform without to S3 bucket logging.
    Default: disabled

" >&2
}

# parse the arguments.
COUNTER=0
ARGS=( "$@" )
while [ $COUNTER -lt $# ]
do

    arg=${ARGS[$COUNTER]}
    let COUNTER=COUNTER+1
    nextArg=${ARGS[$COUNTER]}

    if [[ $skipNext -eq 1 ]]; then
        echo "Skipping"
        skipNext=0
        continue
    fi

    argKey=""
    argVal=""
    if [[ "$arg" =~ ^\- ]]; then
        # if the format is: -key=value
        if [[ "$arg" =~ \= ]]; then
            argVal=$(echo "$arg" | sed 's/\(^-\+[a-z]\+\)\(=\)\(.*\)/\1\t\3/g'|cut -f2)
            argKey=$(echo "$arg" | sed 's/\(^-\+[a-z]\+\)\(=\)\(.*\)/\1\t\3/g'|cut -f1)
            skipNext=0

        # if the format is: -key value
        elif [[ ! "$nextArg" =~ ^\- ]]; then
            argKey="$arg"
            argVal="$nextArg"
            skipNext=1

        # if the format is: -key (a boolean flag)
        elif [[ "$nextArg" =~ ^\- ]] || [[ -z "$nextArg" ]]; then
            argKey="$arg"
            argVal=""
            skipNext=0
        fi
    # if the format has not flag, just a value.
    else
        argKey=""
        argVal="$arg"
        skipNext=0
    fi

    case "$argKey" in 
        -a | --action)
            ACTION="$argVal"
        ;;
        -e | --env | --environment)
            ENVIRONMENT="$argVal"
        ;;
        -o | --override)
            OVERRIDE="$argVal"
        ;;
        -p | --profile | --aws_profile)
            AWSPROFILE="$argVal"
        ;;
        -j | --project)
            PROJECT="$argVal"
        ;;
        -l | --s3_log_bucket)
            S3LOGBUCKET="$argVal"
        ;;
        -b | --s3_bucket_region)
            S3BUCKETREGION="$argVal"
        ;;
        -v | --var | --var-file)
            VARFILE="$argVal"
        ;;
        -r | --region)
            REGION="$argVal"
        ;;
        -f | --force)
            FORCE="1"
        ;;
        -h|--help|-help|--h)
            showUsage
            return
        ;;
    esac
done
# Check if environment is set
if [ -z "$ENVIRONMENT" ]; then
  echo "--!!!WARNING!!!-- Default environment DEV will be used."
  ENVIRONMENT="dev"
fi
# Setting S3 Logging path
if [ -f '/etc/os-release' ]; then
	DATE_ARGS=""
else
	DATE_ARGS="-j"
fi
LOGFILE="tfplan.log"
CURYEAR="$(date ${DATE_ARGS} '+%Y')"
CURMON="$(date ${DATE_ARGS} '+%m')"
CURDAY="$(date ${DATE_ARGS} '+%d')"
CURHRS="$(date ${DATE_ARGS} '+%H%M%S')"
FOLDER="$(basename ${CURENT_LOCATION})"
S3LOGDIR="$(echo $CURENT_LOCATION|rev | cut -d/ -f -2 | rev)"
S3FULLPATH="${S3LOGDIR}/${CURYEAR}/${CURMON}/${CURDAY}/tfplan.log${CURHRS}"
# Check if S3LOGBUCKET is set 
if [ -z "$S3LOGBUCKET" ]; then
	S3LOGBUCKET=$(config_get s3_log_bucket); 
fi
# Check if OVERRIDE is set 
if [ -z "$OVERRIDE" ]; then
	OVERRIDE=$(config_get override); 
fi
if [ -z "$OVERRIDE" ]; then
	OVERRIDE=$ENVIRONMENT;
fi
# Check if REGION is set 
if [ -z "$REGION" ]; then
	REGION=$(config_get region); 
fi
# Check if S3BUCKETREGIONis set 
if [ -z "$S3BUCKETREGION" ]; then
	S3BUCKETREGION=$(config_get s3_bucket_region); 
fi
# Check if AWSPROFILE set 
if [ -z "$AWSPROFILE" ]; then
	AWSPROFILE="$(config_get aws_profile)"; 
fi
# Check if PROJECT set 
if [ -z "$PROJECT" ]; then
	PROJECT="$(config_get project)"; 
fi
# Export AWS Credentials for getting AWS Account ID
export AWS_DEFAULT_REGION="${REGION}"
if [ "$AWSPROFILE" != "0" ]; then
	export AWS_PROFILE="${AWSPROFILE}"
fi
AWSACCOUNT="$(aws sts get-caller-identity --query 'Account' --out text)"
S3BUCKET="terraform-state-${PROJECT}-${OVERRIDE}-${AWSACCOUNT}-${REGION}"
echo "Running on Environment: $ENVIRONMENT ,  AWSACCOUNT: $AWSACCOUNT"
cd $CURENT_LOCATION 
#pwd
# Writing Backend file
cat << EOF > "$CURENT_LOCATION/backend.tf"
terraform {
  backend "s3" {
    bucket = "${S3BUCKET}"
    key    = "tfstates/${OVERRIDE}/${FOLDER}.tfstate"
    region = "${S3BUCKETREGION}"
    dynamodb_table = "${S3BUCKET}"
    encrypt       = true
  }
}
EOF

cat $CURENT_LOCATION/backend.tf

rm -rf ".terraform/terraform.tfstate"
terraform init > /dev/null
# Check Terraform -var-file
if [ ! -z "$VARFILE" ]; then
	VARFILE="${VARFILE}"
else
	VARFILE="variables/${ENVIRONMENT}.tfvars"
fi
GITBRANCH="$(git_current_branch)"
BRANCH=$(config_get branch); 
if [ -z "$BRANCH" ]; then
	BRANCH="develop"
fi
eval "arr=($BRANCH)"
for s in ${arr[@]}; do 
	echo "Check if BRANCH $s == Current Branch - ${GITBRANCH}"
	if [ "$GITBRANCH" == "$s" ]; then
		echo "FORCE applying as branch is $GITBRANCH"
		FORCE="1"
	fi
done
# Run "terraform apply/destroy" if action(-a) is set
if [ ! -z "$ACTION" ] && [ "$ACTION" == "apply" ]; then
	if [ ! -f $VARFILE ]; then
		echo "Terraform -var-file ${VARFILE} couldn't be found. Exit!"
		return
	fi
	if [ ! -z "$S3LOGBUCKET" ]; then
		if [ -z "$FORCE" ] ; then
			echo "-- Run Terraform apply and log to s3://${S3LOGBUCKET}/${S3FULLPATH} ---"
			terraform plan -var-file $VARFILE > $LOGFILE
			terraform apply -var-file $VARFILE
			test -r $LOGFILE && aws s3 cp $LOGFILE "s3://${S3LOGBUCKET}/${S3FULLPATH}" || true
		elif [ ! -z "$FORCE" ] && [ "$FORCE" -eq 1 ]; then
	        	echo "-- FORCE Run Terraform apply ---"
			terraform plan -var-file $VARFILE > $LOGFILE
			terraform apply -auto-approve -var-file $VARFILE
			test -r $LOGFILE && aws s3 cp $LOGFILE "s3://${S3LOGBUCKET}/${S3FULLPATH}" || true
		fi
	fi
elif [ ! -z "$ACTION" ] && [ "$ACTION" == "destroy" ]; then
	if [ ! -f $VARFILE ]; then
		echo "Terraform -var-file ${VARFILE} couldn't be found. Exit!"
		return
	fi
	if [ ! -z "$S3LOGBUCKET" ]; then
		echo "!!! Warning Run Terraform destroy and log to s3://${S3LOGBUCKET}/${S3FULLPATH}.destroy !!!"
		terraform plan -destroy -var-file $VARFILE > $LOGFILE
		terraform apply -destroy -var-file $VARFILE
		test -r $LOGFILE && aws s3 cp $LOGFILE "s3://${S3LOGBUCKET}/${S3FULLPATH}.destroy" || true
	elif [ ! -z "$FORCE" ] && [ "$FORCE" -eq 1 ]; then
		echo "!!! WARNING FORCE Run Terraform DESTROY !!!"
		#terraform plan -destroy -var-file $VARFILE > $LOGFILE
		terraform plan -destroy -var-file $VARFILE
		#terraform apply -auto-approve -destroy -var-file $VARFILE
		#test -r $LOGFILE && aws s3 cp $LOGFILE "s3://${S3LOGBUCKET}/${S3FULLPATH}.destroy" || true
	fi
fi

