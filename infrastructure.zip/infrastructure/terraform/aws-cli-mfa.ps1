# Execute:
#   source ./aws-cli-mfa.ps1 AWS_ACCOUNT_ID MFA_TOKEN AWS_PROFILE USER
#
# Description:
#   Makes assuming an AWS IAM role (+ exporting new temp keys) easier
if ( !$args[3] ){
  $username = "dspitsin"
}else{
  $username = $args[3]
}

$account =  $args[0]
$token =  $args[1]
$profile =  $args[2]

echo "Username: $username" 
echo "Account: $account"
echo "MFA Token: $token"
echo "AWS Profile: $profile"

if ( $args[0] -eq "unset" ){
  Remove-Item Env:\AWS_SESSION_TOKEN
  Remove-Item Env:\AWS_ACCESS_KEY_ID
  Remove-Item Env:\AWS_SECRET_ACCESS_KEY
}else{
  Remove-Item Env:\AWS_SESSION_TOKEN
  Remove-Item Env:\AWS_ACCESS_KEY_ID
  Remove-Item Env:\AWS_SECRET_ACCESS_KEY
  echo "aws sts get-session-token --serial-number arn:aws:iam::$account`:mfa/$username --token-code $token --profile $profile --out json"
  $creds = & aws sts get-session-token --serial-number arn:aws:iam::$account`:mfa/$username --token-code $token --profile $profile --out json | ConvertFrom-Json
	$accessKey = $creds.Credentials.AccessKeyId
	$secretKey = $creds.Credentials.SecretAccessKey
	$token = $creds.Credentials.SessionToken
  $env:AWS_ACCESS_KEY_ID = "$accessKey"
  $env:AWS_SECRET_ACCESS_KEY ="$secretKey"
  $env:AWS_SESSION_TOKEN = "$token"

  Get-Childitem Env: | Where-Object {$_.Name -like "AWS_*"}
}


