## App EKS

## Usage
# Locals section:
```
  # the commented out worker group list below shows an example of how to define
  # multiple worker groups of differing configurations
  worker_groups = [
    {
      asg_desired_capacity = 2
      asg_max_size = 10
      asg_min_size = 2
      instance_type = "m4.xlarge"
      name = "worker_group_a"
      additional_userdata = "echo foo bar"
      subnets = "${join(",", module.vpc.private_subnets)}"
    },
    {
      asg_desired_capacity = 1
      asg_max_size = 5
      asg_min_size = 1
      instance_type = "m4.2xlarge"
      name = "worker_group_b"
      additional_userdata = "echo foo bar"
      subnets = "${join(",", module.vpc.private_subnets)}"
    },
  ]
```
```
  # the commented out worker group tags below shows an example of how to define
  # custom tags for the worker groups ASG
  worker_group_tags = {
    worker_group_a = [
      {
        key                 = "k8s.io/cluster-autoscaler/node-template/taint/nvidia.com/gpu"
        value               = "gpu:NoSchedule"
        propagate_at_launch = true
      },
    ],
    worker_group_b = [
      {
        key                 = "k8s.io/cluster-autoscaler/node-template/taint/nvidia.com/gpu"
        value               = "gpu:NoSchedule"
        propagate_at_launch = true
      },
    ],
  }
```
```
  worker_groups = [
    {
      # This will launch an autoscaling group with only On-Demand instances
      instance_type        = "${var.instance_type[var.environment]}"
      additional_userdata  = "${data.template_file.userdata.rendered}"
      subnets              = "${join(",", data.terraform_remote_state.vpc.subnets_app)}"
      asg_desired_capacity = "1"
      asg_max_size = 6
      asg_min_size = 1
      enable_monitoring    = "true"
      ebs_optimized = "true"
    },
  ]
  worker_groups_launch_template = [
    {
      # This will launch an autoscaling group with only Spot Fleet instances
      instance_type                            = "${var.instance_type[var.environment]}"
      #additional_userdata                      = "echo foo bar"
      subnets                                  = "${join(",", var.private_subnets_id)}"
      additional_security_group_ids            = "${aws_security_group.worker_group_mgmt_one.id},${aws_security_group.worker_group_mgmt_two.id}"
      override_instance_type                   = "${var.instance_type[var.environment]}"
      asg_desired_capacity                     = "3"
      spot_instance_pools                      = 10
      on_demand_percentage_above_base_capacity = "0"
    },
  ]
```
# Module section:
```
  #Can be used if worker_groups_launch_template present
  worker_groups_launch_template        = "${local.worker_groups_launch_template}"
```
```
  # Can be inserted advanced Security Groups(AWS Limits per Network Interface by Customer)
  worker_additional_security_group_ids = ["${aws_security_group.all_worker_mgmt.id}"]
```
### Update modules if modules changed
```
terraform init -update
```

### Plan

```
terraform plan
```

### Apply

```
terraform apply
```

### Destroy

```
terraform destroy
```
