#!/bin/bash

# Parameters
# S3_BUCKET="${s3_bucket}"
# ENVIRONMENT="${environment}"
# DOMAIN_NAME="${domain_name}"
# SECRETSMANAGER_RSS="${secretsmanager_secret}"
# SECRETSMANAGER_COVEO_ADMIN="${secretsmanager_coveo_admin}"
# REGION="${region}"
# FRONT_NAME="${front_name}"

# aws s3 cp s3://s3-lgcomus-coveo/libjq1_1.5.deb /tmp/libjq1.deb
# aws s3 cp s3://s3-lgcomus-coveo/jq_1.5.deb /tmp/jq.deb
# dpkg -i /tmp/libjq1.deb
# dpkg -i /tmp/jq.deb

# SECRET="$(aws secretsmanager get-secret-value --secret-id ${secretsmanager_secret} --region ${region} --out text --query 'SecretString')"
# DB_USER="$(echo $SECRET | jq '.username'|sed 's/^"\(.*\)"$/\1/g')"
# DB_PASSWORD="$(echo $SECRET | jq '.password'|sed 's/^"\(.*\)"$/\1/g')"
# DB_HOST="$(echo $SECRET | jq '.host'|sed 's/^"\(.*\)"$/\1/g')"
# DB_NAME="lg_${environment}"
# DB_MQ_NAME="lg_${environment}_mq"

# echo "Getting env.php from ${s3_bucket}"
# aws s3 cp s3://${s3_bucket}/${environment}/env.php /tmp/env.php
# ## Change the new database details in below values in env.php
# #cd /var/www/lg-qa/deploy/current/app/etc
# sed -i "s/DB_USER/$${DB_USER}/g" /tmp/env.php
# sed -i "s/DB_PASSWORD/$${DB_PASSWORD}/g" /tmp/env.php
# sed -i "s/DB_HOST/$${DB_HOST}/g" /tmp/env.php
# sed -i "s/DB_NAME/$${DB_NAME}/g" /tmp/env.php
# sed -i "s/DB_MQ_NAME/$${DB_MQ_NAME}/g" /tmp/env.php
# sed -i 's/FRONT_NAME/${front_name}/g' /tmp/env.php
# cp /var/www/lg-qa/deploy/current/app/etc/env.php /var/www/lg-qa/deploy/current/app/etc/env.php.b
# cp /tmp/env.php /var/www/lg-qa/deploy/current/app/etc/env.php
# chown www-data /var/www/lg-qa/deploy/current/app/etc/env.php

# echo "Getting Nginx conf from ${s3_bucket}"
# aws s3 cp s3://${s3_bucket}/${environment}/nginx_default.conf /tmp/nginx_default.conf
# ## Update Virtual Host in Nginx
# #sed -i 's/_SERVER_NAME_/${domain_name}/g' /tmp/nginx_default.conf
# sed -i 's/_SERVER_NAME_/_/g' /tmp/nginx_default.conf
# sed -i 's/FRONT_NAME/${front_name}/g' /tmp/nginx_default.conf
# cp /etc/nginx/sites-enabled/default /root/nginx_default.confORG
# cp /tmp/nginx_default.conf /etc/nginx/sites-enabled/default

#_SERVER_NAME_
#'FRONT_NAME'
#'DB_HOST',
#'DB_NAME',
#'DB_MQ_NAME',
#'DB_USER',
#'DB_PASSWORD',

# chown -R www-data:admin /var/www/${front_name}/deploy/current/generated/code
# chown -R www-data:admin /var/www/${front_name}/deploy/current/generated/metadata
# chown -R www-data:admin /var/www/${front_name}/deploy/current/var/cache
# cd /var/www/${front_name}/deploy/current
# sudo -u www-data php bin/coveo setup:upgrade
# sudo -u www-data php bin/coveo setup:di:compile
# sudo -u www-data php bin/coveo setup:static-content:deploy en_US
# sudo -u www-data php bin/coveo cache:flush

# ## Create a Coveo admin user for logging coveo admin panel. Please use the below command to create an admin user.
# COVEO_ADMIN_SECRET="$(aws secretsmanager get-secret-value --secret-id ${secretsmanager_coveo_admin} --region ${region} --out text --query 'SecretString')"
# COVEO_USER="$(echo $COVEO_ADMIN_SECRET | jq '.username'|sed 's/^"\(.*\)"$/\1/g')"
# COVEO_PASSWORD="$(echo $COVEO_ADMIN_SECRET | jq '.password'|sed 's/^"\(.*\)"$/\1/g')"
# COVEO_EMAIL="$(echo $COVEO_ADMIN_SECRET | jq '.email'|sed 's/^"\(.*\)"$/\1/g')"
# COVEO_FIRSTNAME="$(echo $COVEO_ADMIN_SECRET | jq '.firstname'|sed 's/^"\(.*\)"$/\1/g')"
# COVEO_LASTNAME="$(echo $COVEO_ADMIN_SECRET | jq '.lastname'|sed 's/^"\(.*\)"$/\1/g')"
# php bin/coveo admin:user:create --admin-user=$COVEO_USER --admin-password=$COVEO_PASSWORD --admin-email=$COVEO_EMAIL --admin-firstname=$COVEO_FIRSTNAME --admin-lastname=$COVEO_LASTNAME

# echo "Update File Permissions"
# chown -R www-data:www-data /var/www/${front_name}/deploy/current/pub/static
# chown -R www-data:admin /var/www/${front_name}/deploy/current/generated/code
# chown -R www-data:admin /var/www/${front_name}/deploy/current/generated/metadata
# chown -R www-data:admin /var/www/${front_name}/deploy/current/var/cache

##Step 7: Restart the Nginx and PHP-FPM services.
# service nginx restart
# service php7.2-fpm restart

