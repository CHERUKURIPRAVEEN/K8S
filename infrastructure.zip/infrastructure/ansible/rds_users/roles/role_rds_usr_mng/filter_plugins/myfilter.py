# Copyright (c) 2017 Ansible Project
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)


from __future__ import (absolute_import, division, print_function)
__metaclass__ = type


from ansible.errors import AnsibleFilterError
from ansible.module_utils.six.moves.urllib.parse import urlsplit
from ansible.utils import helpers

def to_usr_dict_list(datadict):
    results = []
    for itemlist in datadict:
### environment - db_host - db_name - user_name = pass
### also remove user_list from userdata list
        for item in itemlist:
            #if ( item.split('/')[-1] != 'user_list' ) and ( item.split('/')[-1] != 'db_admin' ):
                userdata = {}
                userdata['username'] = item.split('/')[-1]
                userdata['schema'] = item.split('/')[-2]
                userdata['project'] = item.split('/')[-3]
                results.append(userdata)
    return results

def get_current_state(datadict, env=None):
### the key value must be user_list and its value is user list from previous run
    results = []
    for item in datadict:
        for user in item['users']:
            data = {}
            data['project'] = 'SECRET-LGCOMUS-RDS-' + env.upper() + '-' + item['project_id'].upper() + '-01'
            data['schema'] = item['schema']
            data['username'] = user['username']
            data['privs'] = user['privs']
            data['collation'] = item.get("collation", "")
            data['encoding'] = item.get("encoding", "")
            results.append(data)
    return results

def get_new_state(datadict):
### make list of new users
    results = []
    data = {}
    for item in datadict :
        key = item['db_host']
        usr = item['usr_name']
### avoid keyerror exeption when key does not exist yet in dict
        if key not in data:
            data.setdefault(key, "")
        if 'db_name' not in data:
            data.setdefault('db_name', "")
        data[key] = data[key] + '\n' + usr
        data['db_name'] = item['db_name']
    return data

def get_users_to_create( current_user_state=None, secretsmanager_user_state=None ):
### make list of users to create 
    results = []
    #starting iteration values
    i = 0
    j = 0

    secretsmanager_user_state_length = len(secretsmanager_user_state)
    current_user_state_length = len(current_user_state)

    while i < secretsmanager_user_state_length:
        while j < current_user_state_length:

            #compare element from first array to second array, remove element if same, 
            #and update second array length
            if secretsmanager_user_state[i]['project'] == current_user_state[j]['project'] and secretsmanager_user_state[i]['schema'] == current_user_state[j]['schema'] and  secretsmanager_user_state[i]['username'] == current_user_state[j]['username'] :

                del current_user_state[j]
                current_user_state_length = len(current_user_state)

            #otherwise move j forward
            else:
                j = j + 1

        #when 2nd while loop is done move i forward and reset j to 0
        i = i + 1
        j = 0

    results = current_user_state
    return results

def get_users_to_delete( secretsmanager_user_state=None, current_user_state=None ):
### make list of users to delete
    results = []
    #starting iteration values
    i = 0
    j = 0

    secretsmanager_user_state_length = len(secretsmanager_user_state)
    current_user_state_length = len(current_user_state)

    while i < current_user_state_length:
        while j < secretsmanager_user_state_length:

            #compare element from first array to second array, remove element if same, 
            #and update second array length
            if current_user_state[i]['project'] == secretsmanager_user_state[j]['project'] and current_user_state[i]['schema'] == secretsmanager_user_state[j]['schema'] and current_user_state[i]['username'] == secretsmanager_user_state[j]['username'] :

                del secretsmanager_user_state[j]
                secretsmanager_user_state_length = len(secretsmanager_user_state)

            #otherwise move j forward
            else:
                j = j + 1

        #when 2nd while loop is done move i forward and reset j to 0
        i = i + 1
        j = 0

    return secretsmanager_user_state

### this state will be saved to ssm user_list parameter
def save_state(datadict):
    data = {}
    results = []
    for item in datadict:
        key = '/' + item['env'] + '/' + item["appname"]  + '/' + item["db_host"] + '/' + item["db_name"] + '/' + 'user_list'
        if key not in data:
            data.setdefault(key, "")
        data[key] = item['usr_name'] + '\n' + data[key]
    return data

def get_db_admins(data):
    admin = {}
    for item in data:
        if item.split('/')[-1] == 'db_admin':
            db_host = item.split('/')[-2]
            adm_name = data[item].split("=")[0]
            adm_pass = data[item].split("=")[1]
            # create keys in dict
            admin.setdefault(db_host, "")
            admin[db_host] = { 'adm_name': adm_name, 'adm_pass': adm_pass}
    return admin


def get_usr_list(datadict):
    results = []
    for item in datadict:
        if 'rds.amazonaws.com' in item:
            if ( item.split('/')[-1] == 'user_list' ):
                results.append(item)
    return results


# ---- Ansible filters ----
class FilterModule(object):

    filter_map = {
        'to_usr_dict_list': to_usr_dict_list,
        'get_current_state': get_current_state,
        'get_new_state': get_new_state,
        'save_state': save_state,
        'get_db_admins': get_db_admins,
        'get_usr_list': get_usr_list,
        'get_users_to_create': get_users_to_create,
        'get_users_to_delete': get_users_to_delete
    }

    def filters(self):
        return self.filter_map

