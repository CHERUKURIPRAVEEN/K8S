# bs-cart-count
BlueSky - Cart Count

## Local development settings
local spring boot env settings

### IDE
* Eclipse(https://www.eclipse.org/downloads/)
* Intellij Community(https://www.jetbrains.com/ko-kr/idea/download)
* VS Code

#### VS Code
>>IDE install
>>* VS Code(https://code.visualstudio.com/)

#### VS Code Extensions
>>Needed Extentions for development
>>* Spring Initializr Java Support
>>* Spring Boot Extension Pack
>>* Spring Boot Tools - boot configuration
>>* Java Dependency Viewer
>>* Debugger for Java
>>* Java Extension Pack - popular java extension
>>* Language Support for Java by Red Hat - code navigation, refactoring
>>* Java Test Runner - JUnit Test
>>* Maven for Java - Maven tool
>>* Lombok Annotations Support for VS Code

### Nexus Lib
- http://nexus.lgcomus-dev.lge.com/

### CI
source management
* Install Git Client
* Create account on Gitlab : https://gitlab-ce.lgcomus.lge.com/
* Clone source code from Gitlab

```
  $ git clone http://gitlab-ce.lgcomus.lge.com/oneview/microservice-template.git
```

### Swagger 2
APIs management
https://microservice.lgcomus-dev.lge.com/us/com/cart/swagger-ui/index.html

### Docker
for using local DB (Windows10 && Ram 8G+)
* install: Docker for window(https://hub.docker.com/editions/community/docker-ce-desktop-windows)

#### Docker network

```
	# create docker network
	$ docker network create microservice-template
	# check docker network
	$ docker network ls
```

#### Docker container
```
	# Docker Container start
	$ docker-compose up -d
	# Docker Container stop
	$ docker-compose down
```
* cf. docker-compose.yaml

#### Flyway
* using flyway gradle plugin for local env.
* cleanup : flywayClean
* run flyway : flywayMigrate

```
  // to delete microservice-template schema 
  ./gradlew flywayClean
  // to execute flyway
  ./gradlew flywayMigrate
```

#### DEV
https://api-dev1.lgcomus-dev.lge.com/us/com/cart/v1