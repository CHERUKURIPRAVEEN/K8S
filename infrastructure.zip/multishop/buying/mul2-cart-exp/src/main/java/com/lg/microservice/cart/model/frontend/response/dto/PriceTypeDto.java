package com.lg.microservice.cart.model.frontend.response.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PriceTypeDto {
	@JsonProperty("value")
	public Double value;
	@JsonProperty("displayText")
	public String displayText;
}
