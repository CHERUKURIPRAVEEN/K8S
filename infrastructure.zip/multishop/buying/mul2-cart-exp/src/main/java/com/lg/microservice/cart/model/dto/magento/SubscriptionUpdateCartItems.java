package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cart"
})
@Data
public class SubscriptionUpdateCartItems {

  @JsonProperty("cart")
  public SubscriptionUpdateCart cart;

}