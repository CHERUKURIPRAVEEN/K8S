package com.lg.microservice.cart.common.exception;

public class LatLngNotFoundException extends BaseException {

	public LatLngNotFoundException() {
		super(Reason.INVALID_LATLNG);
	}
}