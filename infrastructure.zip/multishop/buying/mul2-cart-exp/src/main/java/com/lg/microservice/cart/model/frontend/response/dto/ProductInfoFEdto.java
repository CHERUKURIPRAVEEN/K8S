package com.lg.microservice.cart.model.frontend.response.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "productId","productCategories", "skuName","modelId","modelName", "productName","productUrl", "qty", "minQty", "maxQty", "price", "img", "features" })
@Data
public class ProductInfoFEdto {

	@JsonProperty("productId")
	public String productId;
	
	@JsonProperty("productCategories")
	public List<ProductCategoriesFEDto> productCategories = null;
	@JsonProperty("eprType")
	public String eprType;
	@JsonProperty("skuName")
	public String skuName;
	@JsonProperty("productUrl")
	public String productUrl;
	@JsonProperty("modelId")
	public String modelId;
	@JsonProperty("modelName")
	public String modelName;
	@JsonProperty("productName")
	public String productName;
	@JsonProperty("qty")
	public Integer qty;
	@JsonProperty("minQty")
	public Integer minQty;
	@JsonProperty("maxQty")
	public Integer maxQty;
	public Boolean hasAccessories;
	public Boolean hasMounting;
	public Boolean hasHandy;
	public Boolean hasEsp;
	public Boolean hasDyamicScheduling;
	public Boolean hasHaulaway;
	public Boolean hasInstallations;
	public Boolean isInstallationAvailable;
	
	@JsonProperty("price")
	public PriceFEdto price;
	@JsonProperty("img")
	public ImgFEdto img;
	@JsonProperty("features")
	public List<FeatureFEdto> features = null;
	public String handyChildItemId;
	public String finalType;
	@JsonProperty("estimatedDeliveryTime")
	public String estimatedDeliveryTime;
	@JsonProperty("selectedDate")
	public String selectedDate;
	@JsonProperty("totalOrderSaving")
	public double totalOrderSaving;
	
}
