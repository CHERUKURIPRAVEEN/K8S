package com.lg.microservice.cart.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class CommonConstants {

	public static final String DELIVERED_EVERY_N_MONTH = "deliveredEveryNMonth";
    public static final String SUCCESS_FLAG = "Y";
    public static final String FAIL_FLAG = "N";
    public static final String DEFAULT_SUCCESS_CODE = StatusCodeConstants.SUCCESS;
    public static final String DEFAULT_SUCCESS_MESSAGE = "Success Response";
    public static final String DEFAULT_FAIL_CODE = StatusCodeConstants.FAIL;

    public static final String NEED_HELP = "needHelp";
    public static final String CART = "cart";
    public static final String ENGLISH_LOCALE = "en";
    
    public static final String ADD_TO_CART_SUCCESS_MESSAGE = "addToCartSuccessMessage";
	public static final String REMOVE_FROM_CART = "removeItemFromCartSuccessMessage";
	public static final String SAVE_DISCOUNT_PRICE = "saveDiscountPrice";
    
    public static final String DELIVERY = "delivery";
    public static final String DELIVERY_TITLE = "deliveryTitle";
    public static final String DESCRIPTION_ROOT_MESSAGE = "descriptionRootMessage";
    public static final String ESTIMATED_DELIVERY_DATE_MSG = "estimatedDeliveryDatemsg";
    public static final String DESCRIPTION_MESSAGE_ROOM_OF_CHOICE = "descriptionMessageRoomofChoice";
	public static final String DESCRIPTION_MESSAGE_WHITEGLOVE = "descriptionMessageWhiteglove";
	public static final String CART_SUBTOTAL = "subtotal";
	public static final String CART_DISCOUNT = "discount";
	public static final String EST_TAX_LABEL = "estTax";
	public static final String CART_ORDER_TOTAL = "orderTotal";
	public static final String CART_PROMO_APPLIED = "promoApplied";
	public static final String ADD_COUPON_TO_CART = "addCouponToCartSuccessMessage";
	public static final String REMOVE_COUPON_FROM_CART = "removeCouponFromCartSuccessMessage";
	public static final String MAGENTO_COUPON_VALIDATION_ERROR = "invalidCouponErrorMessage";
	public static final String UPDATE_ITEM_MESSAGE = "updateItemSuccessMessage";
	public static final String IN_STOCK_TRUE_MESSAGE = "instockTruemessage";
	public static final String IN_STOCK_FALSE_MESSAGE = "instockFalsemessage";
    
	public static final String ESP_TITLE = "espTitle";
	public static final String ESP_ADDED_DESCRIPTION = "espAddedDescription";
	public static final String ESP_OPTION_STRING = "espOption";
	public static final String FILTER_SUBSCRIPTION_STRING = "filterSubscription";
	public static final String DATE_SELECTED_SUCCESSFULLY = "dateSelection";
	public static final String TEMP_OUT_STOCK_MESSAGE = "tempOutofstockMessage";
	public static final String POWERED_BY_HANDY = "poweredByHandy";
    public static final String DELIVERY_OPTIONS = "deliveryOptions";
	public static final String MERGE_SUCCESSFULLY = "mergeSuccessfully";
	public static final String TOTAL_SAVINGS = "totalSavings";
    
    public static final String HANDY_NOT_ADDED_DESCRIPTION = "handyNotAddedDescription";
	public static final String HANDY_OPTION_ITEM_DESCRIPTION = "handyoptionItemDescription";
	public static final String SUBSCRIPTION_DESCRIPTION_WHEN_SELECTED = "subscriptionDescriptionWhenSelected";
	public static final String SUBSCRIPTION_LG_LINK = "subscriptionLGLink";
	public static final String ADDITIONAL_SUBSCRIPTION_DESCRIPTION = "additionalSubscriptionDescription";
	public static final String SHIPPING = "shipping";
	public static final String FREE = "free";
	public static final String CART_ITEM_TITLE = "itemTitle";
	public static final String CART_ROOT_MESSAGE = "rootMessage";
	public static final String TV_MOUNTING_HANDY = "tvMounting";
	public static final String START_DATE_STRING = "startDateString";
	public static final String ADDED_HANDY_DESCRIPTION = "addedHandydescription";
	public static final String NOTABLETOSHIP = "notAbleToShip";
	public static final String SUBSCRIPTION = "subscription";
	public static final String NO_SUBSCRIPTION = "noSubscription";
	public static final String NO_ITEMS_IN_CART = "noItemsInCart";
	public static final String UPDATE_SUCCESSFULL = "updateSuccessfull";
	public static final String CART_CONTENT_KEY = "cartgroup1";

	public static final String ESP_MODAL_KEY = "espModal";

	//Haulaway & Installation
	public static final String HAUL_AWAY_PRODUCTS_KEY = "haulAwayProductsKey";
	public static final String INSTALLATION_PRODUCTS_KEY = "installationProductsKey";
	public static final String HAUL_AWAY_INSTALLAITON_KEY = "haulAwayInstallationKey";
	public static final String HANDY_OPTION_KEY = "handyOptionKey";
	public static final String HAULING_SERVICE_TITLE = "haulingServiceTitle";
	public static final String INSTALLATION_AND_ADDITIONAL_PARTS_STRING = "installationAndAdditionalParts";
	public static final String HAULAWAY_DESCRIPTION = "haulAwayDescription";
	public static final String INSTALLATION_SERVICES = "installationServices";
	public static final String INSTALLATION_DESCRIPTION = "installationDescription";
	public static final String HAULAWAY_INCLUDED = "haulawayIncluded";
	public static final String MTAR_INCLUDED = "mtarIncluded";
	public static final String MTAR_ADDED_DESCRIPTION = "mtarAddedDescription";
	public static final String HAULAWAY_AND_MOVING_DESCRIPTION = "haulawayAndMovingDescription";
	public static final String INSTALLATION_INCLUDED_STRING = "installationIncludedString";
	public static final String INSTALLATION_ADDED_STRING = "installationAdded";
	public static final String HANDY_TITLE = "handyTitle";
	public static final String ZIPCODE_SET_CART = "zipcodeSettoCart";
	public static final String SHIPPPING_FOOTPRINT_MESSAGE = "shippingFootPrintMsg";
	public static final String OFF_DISCOUNT_PRICE = "offDiscountPrice";

    public static final String DELIVERY_NOTIFICATON = "deliveryNotification";
    public static final String HAUL_AWAY_TITLE = "haulAwayTitle";
   	public static final String MTAR_TITLE = "mtarTitle";
	public static final String INSTALLATION_TITLE = "installationTitle";
	public static final String INSTALLATION_NONE_TITLE = "installationNoneTitle";
	public static final String DAILOG_CONTENT_1 = "dailogContent1";
	public static final String DAILOG_CONTENT_2 = "dailogContent2";
}
