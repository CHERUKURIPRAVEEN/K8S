package com.lg.microservice.cart.constant;

public class StatusCodeConstants {
    private StatusCodeConstants() {
        throw new IllegalStateException("Constants class");
    }

    public static final String SUCCESS = "SUCCESS";
    public static final String FAIL = "FAIL";

    public static final String BAD_REQUEST = "BAD.REQUEST";
    public static final String INTERNAL_SERVER_ERROR = "INTERNAL.SERVER.ERROR";

    public static final String INVALID_PARAM = "INVALID.PARAM";
    public static final String NO_MANDATORY_PARAM = "NO.MANDATORY.PARAM";

}
