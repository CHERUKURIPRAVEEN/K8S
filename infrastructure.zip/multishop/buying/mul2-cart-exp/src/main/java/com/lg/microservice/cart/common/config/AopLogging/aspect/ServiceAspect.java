package com.lg.microservice.cart.common.config.AopLogging.aspect;


import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.context.ApplicationContext;
import org.springframework.validation.BeanPropertyBindingResult;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.lg.microservice.cart.constant.LogConstants;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Aspect
@Slf4j
@Data
public class ServiceAspect {

    private String prefix = LogConstants.SVC_PREFIX;
    private boolean enabled = false;
    private List<String> exclude = new ArrayList<>();

    @Around("within(@org.springframework.stereotype.Service *)")
    public Object serviceLogging(ProceedingJoinPoint joinPoint) throws  Throwable{

        Object returnValue = null;

        String className = joinPoint.getSignature().getDeclaringTypeName();
        if (enabled && !exclude.contains(className)){
            String methodName = joinPoint.getSignature().toLongString();

            StringBuffer beforeMethodLog = new StringBuffer();

            beforeMethodLog.append("\n");
            beforeMethodLog.append(prefix + " Class : " + className + "\n");
            beforeMethodLog.append(prefix + " Method : " + methodName + "\n");

            String modelName = "";
            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            Object[] obj = joinPoint.getArgs();

            for (int inx = 0; inx < obj.length; inx++) {

                if (obj[inx] == null || obj[inx] instanceof ServletRequest || obj[inx] instanceof ServletResponse) {

                    
                } else if (obj[inx] instanceof String) {

                    beforeMethodLog.append(prefix + " Input Parameter Value : " + obj[inx].toString() + "\n");

                    
                } else if (obj[inx] instanceof Integer) {
                    beforeMethodLog.append(prefix + " Input Parameter Value : " + Integer.parseInt(obj[inx].toString()) + "\n");

                    
                } else if (obj[inx] instanceof List) {
                    List<?> list = (List<?>)obj[inx];
                    Class<? extends Object> cls = list.get(0).getClass();
                    modelName = cls.getName();
                    beforeMethodLog.append(prefix + " Input Parameter Value : " + modelName + "[" + (list.size() - 1) + "]\n");
                    for (int jnx = 0; jnx < list.size(); jnx++) {
                        String clsInfo = gson.toJson(list.get(jnx));
                        beforeMethodLog.append(clsInfo + "\n");
                    }
                   
                } else {
                    Class<? extends Object> cls = obj[inx].getClass();
                    modelName = cls.getName();
                    beforeMethodLog.append(prefix + " Input Parameter Value : " + modelName + "\n");

                    if (!(obj[inx] instanceof ApplicationContext)) {
                        String clsInfo = gson.toJson(obj[inx]);
                        beforeMethodLog.append(clsInfo + "\n");
                    }
                }
            }
            log.info(beforeMethodLog.toString());

            returnValue = joinPoint.proceed();

            StringBuffer afterMethodLog = new StringBuffer();
            afterMethodLog.append("\n");

            if (returnValue == null || returnValue instanceof BeanPropertyBindingResult
                    || returnValue instanceof ServletRequest || returnValue instanceof ServletResponse) {
                // Do Nothing

            } else {
                String clsInfo = "";

                if (returnValue instanceof List) {
                    List<?> resultList = (List<?>)returnValue;
                    if (!resultList.isEmpty()) {
                        Class<? extends Object> cls = resultList.get(0).getClass();
                        modelName = cls.getName();
                        afterMethodLog.append(prefix + " Result : " + modelName + "[" + (resultList.size() - 1) + "]" + "\n");
                        afterMethodLog.append(prefix + " Result Size : " + resultList.size() + "\n");

                        int resultListSize = resultList.size();

                        for (int knx = 0; knx < resultListSize; knx++) {
                            clsInfo = gson.toJson(resultList.get(knx));
                            afterMethodLog.append(clsInfo + "\n");
                        }
                    } else {
                        afterMethodLog.append(prefix + " Result Size : " + resultList.size() + "\n");
                    }
                } else {
                    clsInfo = gson.toJson(returnValue);
                    afterMethodLog.append(prefix + " Result : " + returnValue.getClass().getName() + "\n");
                    afterMethodLog.append(clsInfo + "\n");
                }
            }
            log.info(afterMethodLog.toString());

        } else {
            returnValue = joinPoint.proceed();
        }

        return returnValue;
    }
}
