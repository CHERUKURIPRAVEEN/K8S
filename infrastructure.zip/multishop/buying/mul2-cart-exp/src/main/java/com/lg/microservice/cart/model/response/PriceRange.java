package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class PriceRange {
	
	 @JsonProperty("maximum_price")
	 private MaximumPrice maximumPrice;

}
