package com.lg.microservice.cart.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cartItemId",
"billingPeriod",
"quantity"
})
@Data
public class SubscrptionOtpionRequestBody {

@JsonProperty("cartItemId")
public Integer cartItemId;
@JsonProperty("billingPeriod")
public String billingPeriod;
@JsonProperty("quantity")
public Integer quantity;

}