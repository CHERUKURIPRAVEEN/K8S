package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class AddCouponToCartRequest {

    @NotBlank
    private String cartId;
    
    @NotBlank
    private String couponCode;
    
    private String token;
    
    private String store;

    public static AddCouponToCartRequest of(String cartId, String couponCode, String token, String store) {
      Objects.requireNonNull(store, couponCode);
        Objects.requireNonNull(cartId);
      return new AddCouponToCartRequest(cartId,couponCode,token,store);
  }

    
}
