package com.lg.microservice.cart.common.exception;

public class UnauthorizedException extends RuntimeException{

}
