package com.lg.microservice.cart.common.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.cloud.openfeign.support.SpringMvcContract;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lg.microservice.cart.feign.MagentoClientDecoder;
import com.lg.microservice.cart.feign.MagentoServiceClient;

import feign.Feign;

@Configuration
@Slf4j
public class FeignClientConfig {


  @Bean
  public MagentoServiceClient buildMagentoClient(MagentoClientProps props,
      ObjectFactory<HttpMessageConverters> messageConvertersObjectFactory,
      ObjectMapper objectMapper) {
    log.info("Cart Microservice Pointing To Magento Endpoint  ----> " + props.getUrl()+ "/graphql");
    return Feign.builder()
        .contract(new SpringMvcContract())
        .decoder(new MagentoClientDecoder(messageConvertersObjectFactory, objectMapper))
        .encoder(new SpringEncoder(messageConvertersObjectFactory))
        .target(MagentoServiceClient.class, props.getUrl());
  }
}
