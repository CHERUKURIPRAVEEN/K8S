package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class GrandTotalDTO {

	@JsonProperty("value")
	private Double value;

	@JsonProperty("currency")
	private String currency;
}
