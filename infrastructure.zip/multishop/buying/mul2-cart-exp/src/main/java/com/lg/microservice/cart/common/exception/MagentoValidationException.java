package com.lg.microservice.cart.common.exception;

import lombok.Data;

@Data
public class MagentoValidationException extends RuntimeException {

  private String message;

  private String redirectTo;
  
  public MagentoValidationException (String message) {
    this.message=message;
  }
  public MagentoValidationException (String message, String redirectTo) {
    this.message=message;
    this.redirectTo=redirectTo;
  }
  public MagentoValidationException () {
	  }
}
