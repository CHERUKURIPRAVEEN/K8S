package com.lg.microservice.cart.model.request;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class UpdateCartItemRequestBody {

	
	@JsonProperty("billingPeriod")
	@Schema(description = "billingPeriod is Specifies the subscription period. Pass option code or null if you want to remove subscription.")
	private String billingPeriod;
	
	@NotBlank(message="Cart ItemId should not be blank")
	@JsonProperty("cartItemId")
	@Schema(description = "cart ItemId should not be blank")
	private String cartItemId;
	
	@JsonProperty("customizableOptions")
	@Schema(description = "customizable Options are optional")
	private CustomizableOptionInput customizableOptions;
	
	@NotBlank(message="Quantity should not be blank")
	@JsonProperty("quantity")
	@Schema(description = "quantity should not be blank")
	private String quantity;

}
