package com.lg.microservice.cart.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.web.bind.annotation.RequestBody;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"patchItem"
})
@Data
public class PatchItemRequestBody {

    @JsonProperty("patchItem")
    public UpdateOptionsRequestBody updateOptions;

    @JsonProperty("removeItem")
    RemoveCartItemBody removeItem;

    @JsonProperty("addItem")
    CartItemRequestBody addItem;

}