package com.lg.microservice.cart.model.response;

import java.util.Map;

public class StoreConfigSubsKeyValueDto {

  private Map<String, StroeConfigSubsValueDto> values;

  public Map<String, StroeConfigSubsValueDto> getValue() {
    return values;
  }

  public void setValue(Map<String, StroeConfigSubsValueDto> value) {
    this.values = value;
  }
}
