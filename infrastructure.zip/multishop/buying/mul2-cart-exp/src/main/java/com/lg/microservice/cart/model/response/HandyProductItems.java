package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HandyProductItems {

	 @JsonProperty("service_products")
	 private List<ProductAccessories> service_products;
}
