package com.lg.microservice.cart.common.config.AopLogging;

import com.lg.microservice.cart.common.config.AopLogging.aspect.ControllerAspect;
import com.lg.microservice.cart.common.config.AopLogging.aspect.PersistentAspect;
import com.lg.microservice.cart.common.config.AopLogging.aspect.ServiceAspect;
import com.lg.microservice.cart.common.config.AopLogging.properties.ControllerProperties;
import com.lg.microservice.cart.common.config.AopLogging.properties.PersistentProperties;
import com.lg.microservice.cart.common.config.AopLogging.properties.ServiceProperties;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.util.StringUtils;

import java.util.Arrays;

@Configuration
@EnableConfigurationProperties({ControllerProperties.class, ServiceProperties.class, PersistentProperties.class})
public class TraceLogConfiguration {
    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(
            prefix = "trace-log-aspect.controller",
            name = {"enabled"},
            havingValue = "true"
    )
    public ControllerAspect controllerAspect(ControllerProperties controllerProperties){
        ControllerAspect controllerAspect = new ControllerAspect();
        controllerAspect.setEnabled(controllerProperties.isEnabled());
        if(StringUtils.hasText(controllerProperties.getPrefix())){
            controllerAspect.setPrefix("\t" + controllerProperties.getPrefix());
        }
        if(StringUtils.hasText(controllerProperties.getExclude())){
            controllerAspect.setExclude(Arrays.asList(StringUtils.commaDelimitedListToStringArray(controllerProperties.getExclude()).clone()));
        }
        return controllerAspect;
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(
            prefix = "trace-log-aspect.service",
            name = {"enabled"},
            havingValue = "true"
    )
    public ServiceAspect serviceAspect(ServiceProperties serviceProperties){
        ServiceAspect serviceAspect = new ServiceAspect();
        serviceAspect.setEnabled(serviceProperties.isEnabled());
        if(StringUtils.hasText(serviceProperties.getPrefix())){
            serviceAspect.setPrefix("\t" + serviceProperties.getPrefix());
        }
        if(StringUtils.hasText(serviceProperties.getExclude())){
            serviceAspect.setExclude(Arrays.asList(StringUtils.commaDelimitedListToStringArray(serviceProperties.getExclude()).clone()));
        }
        return serviceAspect;
    }

    @Bean
    @ConditionalOnMissingBean
    @ConditionalOnProperty(
            prefix = "trace-log-aspect.persistent",
            name = {"enabled"},
            havingValue = "true"
    )
    public PersistentAspect persistentAspect(PersistentProperties persistentProperties){
        PersistentAspect persistentAspect = new PersistentAspect();
        persistentAspect.setEnabled(persistentProperties.isEnabled());
        if(StringUtils.hasText(persistentProperties.getPrefix())){
            persistentAspect.setPrefix("\t" + persistentProperties.getPrefix());
        }
        if(StringUtils.hasText(persistentProperties.getExclude())){
            persistentAspect.setExclude(Arrays.asList(StringUtils.commaDelimitedListToStringArray(persistentProperties.getExclude()).clone()));
        }
        return persistentAspect;
    }
}
