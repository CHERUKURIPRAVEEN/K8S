package com.lg.microservice.cart.model.response;

import java.util.List;

import com.lg.microservice.cart.model.dto.magento.MagentoError;
import com.lg.microservice.cart.model.dto.magento.Status;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MagentoResponseBody {

	private Status status;
	
	private String zipCode;

	private String cartid;

	private List<MagentoError> errors;

}
