package com.lg.microservice.cart.model.dto.magento;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"applied_coupons", "prices"})
@Data
public class CartOrderSummaryDTO {
	@JsonProperty("shipping_addresses")
	public List<ShippingAddressDetails> shipping_addresses = null;
    @JsonProperty("applied_coupons")
    public List<AppliedCouponDto> applied_coupons = null;
    @JsonProperty("prices")
    public PricesOrderSummaryDto prices;
    @JsonProperty("applied_wee_taxes")
    public List<AppliedWeeTaxDto> appliedWeeTaxes;
}
