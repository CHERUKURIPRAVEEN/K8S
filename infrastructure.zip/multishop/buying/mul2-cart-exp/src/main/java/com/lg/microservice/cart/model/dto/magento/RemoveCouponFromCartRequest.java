package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class RemoveCouponFromCartRequest {

  @NotBlank
  private String cartId;
  
  private String token;
  
  private String store;
 
  public static RemoveCouponFromCartRequest of(String cartId, String token, String store) {
    Objects.requireNonNull(cartId);
    Objects.requireNonNull(store,token);
    
    return new RemoveCouponFromCartRequest(cartId,token,store);
}

  
}
