package com.lg.microservice.cart.model.frontend.response.dto;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.dto.magento.MagentoError;
import com.lg.microservice.cart.model.dto.magento.UpdateShippingOptionResponse;
import lombok.Data;

@Data
public class RootUpdateShippingOptionResponse {

  @JsonProperty("setShippingMethodsOnCart")
  public UpdateShippingOptionResponse setShippingMethodsOnCart;
 
  @JsonProperty("statusCode")
  private Integer status;
  
  @JsonProperty("errors")
  private List<MagentoError> errors;
}
