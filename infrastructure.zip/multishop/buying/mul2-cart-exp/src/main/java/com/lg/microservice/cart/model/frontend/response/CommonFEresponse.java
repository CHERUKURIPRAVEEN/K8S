package com.lg.microservice.cart.model.frontend.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonFEresponse {

	private String successMessage;
	
	private Integer statusCode;
}
