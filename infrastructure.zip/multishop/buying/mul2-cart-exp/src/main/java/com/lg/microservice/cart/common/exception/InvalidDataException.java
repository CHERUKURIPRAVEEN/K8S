package com.lg.microservice.cart.common.exception;

public class InvalidDataException extends BaseException {

	public InvalidDataException(String cartId) {
		super(Reason.INVALID_DATA);
	}

	public InvalidDataException() {
		super(Reason.INVALID_DATA);
		}

}
