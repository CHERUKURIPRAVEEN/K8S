package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ProductItems {

	 @JsonProperty("accessory_products")
	 private List<ProductAccessories> accessoryProducts;
}
