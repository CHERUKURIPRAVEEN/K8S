package com.lg.microservice.cart.model.dto.magento;
import lombok.*;

import javax.validation.constraints.NotBlank;
import java.util.Objects;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseLimitRequest {

    @NotBlank
    private String token;

    @NotBlank
    private String store;

    @NotBlank
    private String email;

    public static PurchaseLimitRequest of(String token, String store,String email) {
        Objects.requireNonNull(token);
        Objects.requireNonNull(store,email);
        return new PurchaseLimitRequest(token, store,email);
    }
}