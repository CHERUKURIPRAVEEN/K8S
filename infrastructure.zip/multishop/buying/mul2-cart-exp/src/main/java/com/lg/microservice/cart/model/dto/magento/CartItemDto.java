package com.lg.microservice.cart.model.dto.magento;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"quantity", "prices", "shippingRates", "product"})
@Data
public class CartItemDto {

	@JsonProperty("id")
	public Integer id;
	@JsonProperty("shippable")
	public Boolean shippable;
	@JsonProperty("warehouse_code")
	public String wareHouseCode;
	@JsonProperty("item_stock")
	public CartItemQuantity item_stock;
	@JsonProperty("group_id")
	public String group_id;
	@JsonProperty("estimated_delivery_time")
	public String estimated_delivery_time;
	@JsonProperty("available_dates")
	public String available_dates;
	@JsonProperty("selected_date")
	public String selected_date;
	@JsonProperty("is_dynamic_scheduling")
	public Boolean is_dynamic_scheduling;
	@JsonProperty("service_parent_item_id")
	public String service_parent_item_id;
	@JsonProperty("service_child_items")
	public List<ServiceChilItem> service_child_items;
	@JsonProperty("quantity")
	public Integer quantity;
	@JsonProperty("ship_to_code")
	public String ship_to_code;
	@JsonProperty("prices")
	public PricesDto prices;
	@JsonProperty("shippingRates")
	public List<ShippingRateDto> shippingRates;
	@JsonProperty("product")
	public ProductDto product;
	@JsonProperty("billing_period")
	public BillingPeriodDto billingPeriod;
	
	@JsonProperty("haul_away_available")
	public Boolean haulAwayAvailable;
	
	@JsonProperty("installation_available")
	public Boolean installationAvailable;

}
