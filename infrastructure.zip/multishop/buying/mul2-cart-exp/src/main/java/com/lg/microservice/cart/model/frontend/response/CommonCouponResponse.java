package com.lg.microservice.cart.model.frontend.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CommonCouponResponse {

    private String message;

    private Integer statusCode;


}
