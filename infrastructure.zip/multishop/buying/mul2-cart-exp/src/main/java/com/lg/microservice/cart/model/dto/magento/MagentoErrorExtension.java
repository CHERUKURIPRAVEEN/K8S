package com.lg.microservice.cart.model.dto.magento;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MagentoErrorExtension {

    private String category;

}
