package com.lg.microservice.cart.common.exception;

public class InvalidZipcodeException extends BaseException {

	public InvalidZipcodeException() {
		super(Reason.INVALID_ZIPCODE);
	}
}
