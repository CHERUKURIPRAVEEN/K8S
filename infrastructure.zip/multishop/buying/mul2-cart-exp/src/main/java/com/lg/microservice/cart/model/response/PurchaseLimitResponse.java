package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.dto.magento.MagentoError;
import lombok.Data;

import java.util.List;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PurchaseLimitResponse {

    @JsonProperty("getPurchaseLimit")
    private PurchaseLimitCustomer purchaseLimit;

    @JsonProperty("statusCode")
    private Integer status;

    @JsonProperty("errors")
    private List<MagentoError> errors;

}
