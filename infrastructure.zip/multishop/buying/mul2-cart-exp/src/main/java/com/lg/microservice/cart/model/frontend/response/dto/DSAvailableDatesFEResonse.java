package com.lg.microservice.cart.model.frontend.response.dto;

import java.util.List;

import lombok.Data;

@Data
public class DSAvailableDatesFEResonse {
	public String cartId;
	public String cartItemId;
	public List<DSDates> availableDates;
}
