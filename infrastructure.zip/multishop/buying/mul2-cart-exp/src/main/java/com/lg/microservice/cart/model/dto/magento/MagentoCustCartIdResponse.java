package com.lg.microservice.cart.model.dto.magento;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.response.CustCartCountId;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MagentoCustCartIdResponse {
	
	@JsonProperty("customerCart")
    private CustCartCountId customerCart;
	
    @JsonProperty("errors")
    private List<MagentoError> errors;
    
}
