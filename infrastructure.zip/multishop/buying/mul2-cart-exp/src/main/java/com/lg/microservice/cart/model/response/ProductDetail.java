package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.frontend.response.dto.PriceFEdto;
import com.lg.microservice.cart.model.frontend.response.dto.StatusDto;

import lombok.Data;

@Data
public class ProductDetail {
	
	@JsonProperty("name")
	private String name;

	@JsonProperty("sku")
	private String sku;

	@JsonProperty("status")
	private StatusDto status;
	
	@JsonProperty("url")
	private String url;
	
	@JsonProperty("imageUrl")
	private String imageUrl;
	
	@JsonProperty("alt")
	private String alt;
	
	@JsonProperty("price")
	private PriceFEdto price;
	
	@JsonProperty("productUrl")
	private String productUrl;
	
	
}
