package com.lg.microservice.cart.model.request;

import lombok.Data;

@Data
public class HandWallMountOptionRequestBody {
  public Integer cartItemId;
  public Integer quantity;
  
}
