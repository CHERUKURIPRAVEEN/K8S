package com.lg.microservice.cart.model.response;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@Builder
public class ResponseData {
    private String successOrNot;
    private String statusCode;
    private int status;
    private String message;
    private Object data;
    
    public ResponseData(String successOrNot, String statusCode, int status, String message, Object data){
        this.successOrNot = successOrNot;
        this.statusCode = statusCode;
        this.status = status;
        this.message = message;
        this.data = data;
    }

}
