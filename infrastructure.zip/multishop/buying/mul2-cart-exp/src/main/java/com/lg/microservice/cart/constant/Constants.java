package com.lg.microservice.cart.constant;

public final class Constants {

    private Constants() {
    }
    
    public static final String SUCCESS = "Success";
    
    public static final String ACCESS_DENIED = "Access denied";
    public static final String BAD_REQUEST = "Bad Request";
    
    public static final String FAILED_TO_DECODE_MAGENTO = "failed to decode magento";
	public static final String FAILED_TO_CONNECT_TO_MAGENTO = "failed to connect to magento";
	public static final String PASS_CART_ID_ERROR = "Invalid Request. Cart Id cannot be blank";
	public static final String TOKEN_NOT_FOUND = "Invalid Request. Token cannot be blank";
	public static final String SSO_VALIDATION = "SSO validation Failed";
	public static final String ZIPCODE_NOT_FOUND = "Invalid Request. Zipcode cannot be blank";
	public static final String INVALID_LATLNG = "Invalid Request. LatLng Cannot be blank";
	public static final String INTERNAL_ERROR =" Failed to Connect Magento";
	public static final String NO_VALID_RESPONSE = "Could not get the valid response from Magento";
	public static final String INVALID_DATA = "Invalid input. Please enter valid data";

	public static final String ADDRESS_VERIFY_API = "https://microservice.lgcomus-dev.lge.com/address/v1/zip-lookup";

}
