package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class AddItemsToCartRequest {

    @NotBlank
    private String cartId;
    
    @NotBlank
    private String store;
    
    @NotBlank
    private String skuID;
    
    @NotBlank
    private String token;
    
    private String handyParentItemId;

    private String zipCode;

    public AddItemsToCartRequest(String cartId, String store, String skuID, String token, String handyParentItemId){
        this.cartId = cartId;
        this.store = store;
        this.skuID = skuID;
        this.token = token;
        this.handyParentItemId = handyParentItemId;
    }
    
    public static AddItemsToCartRequest of(String cartId, String store, String skuID, String token, String handyParentItemId, String zipCode) {
        Objects.requireNonNull(cartId, store);
     
        Objects.requireNonNull(skuID,token);
        return new AddItemsToCartRequest(cartId, store, skuID, token, handyParentItemId, zipCode);
    }

    public static AddItemsToCartRequest of(String cartId, String store, String skuID, String token, String handyParentItemId) {
        Objects.requireNonNull(cartId, store);

        Objects.requireNonNull(skuID,token);
        return new AddItemsToCartRequest(cartId, store, skuID, token, handyParentItemId);
    }
    
}