package com.lg.microservice.cart.common.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ExceptionResponse {

  private String message;
  private String redirectTo;
  private Integer statusCode;
  
}
