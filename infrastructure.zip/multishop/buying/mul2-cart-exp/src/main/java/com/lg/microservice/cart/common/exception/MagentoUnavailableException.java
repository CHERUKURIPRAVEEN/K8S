package com.lg.microservice.cart.common.exception;

public class MagentoUnavailableException extends BaseException {

    public MagentoUnavailableException() {
        super(Reason.MAGENTO_UNAVAILABLE);
    }
}
