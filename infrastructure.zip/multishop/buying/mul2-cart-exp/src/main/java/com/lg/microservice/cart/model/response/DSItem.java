package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"id", "available_dates"})
@Data
public class DSItem {

	@JsonProperty("id")
	public String id;
	@JsonProperty("available_dates")
	public String availableDates;

}