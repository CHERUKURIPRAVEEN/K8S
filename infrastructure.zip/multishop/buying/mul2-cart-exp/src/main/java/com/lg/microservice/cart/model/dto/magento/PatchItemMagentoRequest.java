package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;
import javax.validation.constraints.NotBlank;
import com.lg.microservice.cart.model.request.PatchItemRequestBody;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class PatchItemMagentoRequest {

    @NotBlank
    private String cartId;
    
    @NotBlank
    private String store;
    
    @NotBlank
    private String token;
    
    @NotBlank
    private PatchItemRequestBody reqBody;

    public static PatchItemMagentoRequest of(String cartId, String store, String token, PatchItemRequestBody patchItemRequestBody) {
        Objects.requireNonNull(cartId, store);
        Objects.requireNonNull(patchItemRequestBody);
        Objects.requireNonNull(token);
        
        return new PatchItemMagentoRequest(cartId, store, token, patchItemRequestBody);
    }
}
