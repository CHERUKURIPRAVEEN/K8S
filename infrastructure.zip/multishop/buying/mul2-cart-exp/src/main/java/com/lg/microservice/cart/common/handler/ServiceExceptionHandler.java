package com.lg.microservice.cart.common.handler;

import java.util.stream.Collectors;

import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.lg.microservice.cart.common.exception.Reason;
import com.lg.microservice.cart.model.dto.ResponseData;
import com.lg.microservice.cart.util.ResponseUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
public class ServiceExceptionHandler {

    @ExceptionHandler(RuntimeException.class)
    public ResponseEntity<ResponseData> onRuntimeException(RuntimeException ex) {
        log.error("Got runtime exception.", ex);
        return ResponseUtil.failed("Something went wrong", HttpStatus.INTERNAL_SERVER_ERROR);
    }

   

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ResponseData> onMethodArgumentNotValidException(MethodArgumentNotValidException ex) {
        String message = getArgumentErrorMessage(ex);
        return ResponseUtil.failed(Reason.INVALID_REQUEST_PARAM, HttpStatus.BAD_REQUEST, message);
    }

    

    private String getArgumentErrorMessage(MethodArgumentNotValidException ex) {
        return ex.getBindingResult().getAllErrors().stream()
                .map(DefaultMessageSourceResolvable::getDefaultMessage)
                .collect(Collectors.joining("; "));
    }

}
