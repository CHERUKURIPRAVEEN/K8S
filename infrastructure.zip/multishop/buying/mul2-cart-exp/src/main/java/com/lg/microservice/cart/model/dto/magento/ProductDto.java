package com.lg.microservice.cart.model.dto.magento;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sku", "stock_status", "quantity", "erp_type", "subscription_enable", "subscription_price", "image", "accessory_products" })
@Data
public class ProductDto {

	@JsonProperty("id")
	public String id;
	@JsonProperty("model_name")
	public String modelName;
	@JsonProperty("parent_product_categories")
	public List<ParentProductCategories> parentProductCategories = null;
	@JsonProperty("stock_warehouses")
	public List<StockWarehouseCodes> StockWarehouseCodes = null;
	@JsonProperty("contract_term_month")
	public String contract_term_month;
	@JsonProperty("is_innovel_item")
	public Boolean is_innovel_item;
	@JsonProperty("min_sale_qty")
	public Integer minSaleQty;
	@JsonProperty("max_sale_qty")
	public Integer maxSaleQty;
	@JsonProperty("name")
	public String name;
	@JsonProperty("productId")
	public String productId;
	@JsonProperty("sku")
	public String sku;
	@JsonProperty("pdp_url")
	public String pdpUrl;
	@JsonProperty("model_id")
	public String modelId;
	@JsonProperty("stock_status")
	public String stockStatus;
	@JsonProperty("quantity")
	public Integer quantity;
	@JsonProperty("erp_type")
	public String erpType;
	@JsonProperty("subscription_enable")
	public Boolean subscriptionEnable;
	@JsonProperty("subscription_price")
	public Integer subscriptionPrice;
	@JsonProperty("subscription_only")
	public Boolean subscription_only;
	@JsonProperty("subscription_discount")
	public String subscription_discount;
	@JsonProperty("subscription_final_price")
	public long subscription_final_price;
	@JsonProperty("subscription_additional_discount")
	public long subscription_additional_discount;

	@JsonProperty("define_start_from")
	public String define_start_from;
	@JsonProperty("day_of_month")
	public String day_of_month;
	@JsonProperty("discount_type")
	public String discount_type;

	@JsonProperty("accessory_products")
	public List<AccessoryProductDto> accessoryProducts = null;
	@JsonProperty("msrp")
	public double msrp;
	@JsonProperty("price_range")
	public PriceRangeDto priceRng;
	@JsonProperty("has_accessories")
	public Boolean has_accessories;
	@JsonProperty("handy_enable")
	public Boolean handy_enable;
	@JsonProperty("esp_enable")
	public Boolean esp_enable;
	@JsonProperty("handy_service_cost")
	public String handy_service_cost;
	@JsonProperty("image")
	public ImageDto image;
	@JsonProperty("service_products")
	public List<ServiceProductDto> serviceProducts = null;
	@JsonProperty("haulaway_service_enable")
	public Boolean haulaway_service_enable;
	@JsonProperty("installation_service_enable")
	public Boolean installation_service_enable;
	@JsonProperty("preorder_enabled")
	public Boolean preOrderEnabled;

}
