package com.lg.microservice.cart.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class LogConstants {
    public final String CTR_PREFIX = "\t[CTR]";
    public final String SVC_PREFIX = "\t[SVC]";
    public final String PER_PREFIX = "\t[PER]";
}
