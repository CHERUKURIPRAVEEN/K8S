package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FinalPrice {
	
	 @JsonProperty("currency")
	 private String currency;
	 
	 @JsonProperty("value")
	 private Double value;
}
