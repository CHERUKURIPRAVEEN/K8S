package com.lg.microservice.cart.common.exception;

public class SSOValidationFailed extends BaseException {

	public SSOValidationFailed() {
		super(Reason.SSO_VALIDATION_FAILED);
	}
}