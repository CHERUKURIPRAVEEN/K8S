package com.lg.microservice.cart.common.exception;

public class FeignBadGatewayException extends RuntimeException {


}
