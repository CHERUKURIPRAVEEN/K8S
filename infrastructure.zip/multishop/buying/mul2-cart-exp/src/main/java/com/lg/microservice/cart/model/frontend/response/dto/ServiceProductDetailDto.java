package com.lg.microservice.cart.model.frontend.response.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ServiceProductDetailDto {

	@JsonProperty("title")
	public String title;
	@JsonProperty("description")
	public String description;
	@JsonProperty("longDescription")
	public String longDescription;
	@JsonProperty("serviceProductType")
	public String serviceProductType;
	@JsonProperty("serviceProductOptions")
	public List<ServiceProductOptions> serviceProductOptions;

}
