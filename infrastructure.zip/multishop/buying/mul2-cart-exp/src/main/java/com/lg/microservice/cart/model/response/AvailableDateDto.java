package com.lg.microservice.cart.model.response;

import java.util.List;

import lombok.Data;

@Data
public class AvailableDateDto {
	public List<String> values;
}
