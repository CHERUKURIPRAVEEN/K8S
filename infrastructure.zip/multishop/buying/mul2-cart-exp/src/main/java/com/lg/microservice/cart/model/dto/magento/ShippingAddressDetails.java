package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class ShippingAddressDetails {

	@JsonProperty("postcode")
	public String postcode;

	@JsonProperty("selected_shipping_method")
	public SelectedShippingMethod selectedShippingMethod;
}
