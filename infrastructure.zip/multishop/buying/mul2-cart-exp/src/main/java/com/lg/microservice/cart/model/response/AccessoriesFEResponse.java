package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AccessoriesFEResponse {

	@JsonProperty("sku")
	private String sku;

	
	@JsonProperty("products")
	private List<ProductDetail> products;
	
	
	

}
