package com.lg.microservice.cart.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CustomizableOptionInput {
	

	@JsonProperty("id")
	@Schema(description = "customizable Options ID")
	private String id;
	

	@JsonProperty("value")
	@Schema(description = "customizable Options VALUE")
	private String value;
	

}
