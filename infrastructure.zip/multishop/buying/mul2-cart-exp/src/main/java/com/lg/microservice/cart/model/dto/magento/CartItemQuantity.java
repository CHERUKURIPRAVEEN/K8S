package com.lg.microservice.cart.model.dto.magento;

import lombok.Data;

@Data
public class CartItemQuantity {
	public Integer qty;
	public String status;
}
