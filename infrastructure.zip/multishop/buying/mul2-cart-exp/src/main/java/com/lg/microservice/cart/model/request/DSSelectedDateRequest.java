package com.lg.microservice.cart.model.request;

import lombok.Data;

@Data
public class DSSelectedDateRequest {

	public String selectedDate;
}
