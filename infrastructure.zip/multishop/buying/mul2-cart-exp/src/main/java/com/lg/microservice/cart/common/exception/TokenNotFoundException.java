package com.lg.microservice.cart.common.exception;

import lombok.Data;

@Data
public class TokenNotFoundException extends RuntimeException {

  String message;
  
  public TokenNotFoundException (String message) {
    this.message=message;
  }
  public TokenNotFoundException () {
	  }
}