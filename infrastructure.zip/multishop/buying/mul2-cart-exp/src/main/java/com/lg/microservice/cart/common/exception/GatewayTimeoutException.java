package com.lg.microservice.cart.common.exception;

public class GatewayTimeoutException extends RuntimeException {

}
