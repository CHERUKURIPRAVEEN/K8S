package com.lg.microservice.cart.model.dto.magento;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.response.CartCountResponse;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MagentoCartCountResponse {
	
	@JsonProperty("cart")
    private CartCountResponse cart;
	
	@JsonProperty("statusCode")
    private Integer status;
    
    @JsonProperty("errors")
    private List<MagentoError> errors;
    
  
}
