package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class DSDateRequest {
	@NotBlank
	private String token;
	@NotBlank
	private String cartId;
	private String selectedDate;

	private String store;

	public static DSDateRequest of(String token, String cartId, String selectedDate, String store) {

		Objects.requireNonNull(token);
		return new DSDateRequest(token, cartId, selectedDate, store);
	}
}
