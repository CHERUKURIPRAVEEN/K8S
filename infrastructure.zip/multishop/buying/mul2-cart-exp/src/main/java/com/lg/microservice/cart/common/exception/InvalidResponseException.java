package com.lg.microservice.cart.common.exception;

public class InvalidResponseException extends BaseException {

	public InvalidResponseException(String cartId) {
		super(Reason.INVALID_RESPONSE);
	}

}
