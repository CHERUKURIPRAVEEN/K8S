package com.lg.microservice.cart.model.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

/**
 * for response wrapper
 */
@Getter
@AllArgsConstructor
public enum ResponseFlag {

    SUCCESS("Y", "Rest call is successfull"), FAIL("N", "Not successfull rest call");

    private final String code;
    private final String description;

}
