package com.lg.microservice.cart.common.exception;

public class ApplicationInternalServerException extends RuntimeException {

}
