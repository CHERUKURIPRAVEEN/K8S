package com.lg.microservice.cart.feign;

import org.springframework.cloud.openfeign.FeignClient;

@FeignClient(name = "ZipcodeUspsClient", url = "${zipcode.usps.url}")
public interface ZipcodeUspsClient {

//    @GetMapping(value = "${zipcode.usps.validate.url}")
//    String getZipcodeValidate(@RequestParam(name = "API") String API, @RequestParam(name = "XML") String XML);

}
