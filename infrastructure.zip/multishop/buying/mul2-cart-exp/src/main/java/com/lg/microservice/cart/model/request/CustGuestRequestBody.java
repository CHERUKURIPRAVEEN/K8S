package com.lg.microservice.cart.model.request;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CustGuestRequestBody {
  
  @NotBlank(message="Customer Cart Id should not be blank")
  @JsonProperty("destcartid")
  @Schema(description = "Customer Cart Id should not be blank")
  private String destcartid;
  
  @NotBlank(message="Guest Cart Id should not be blank")
  @JsonProperty("srccartid")
  @Schema(description = "Guest Cart Id should not be blank")
  private String srccartid;
 
}