package com.lg.microservice.cart.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import javax.validation.constraints.NotBlank;

@Data
public class AddModelToCartBody {

    @JsonProperty("itemId")
    @NotBlank(message="product SKU id should not be blank")
    @Schema(description = "product SKU id should not be blank")
    private String itemId;

    @JsonProperty("isHandy")
    @Schema(description = "isHandy flag is optional")
    private boolean isHandy;

}
