package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class AccessoryProductDto {

@JsonProperty("id")
public Integer id;  
@JsonProperty("name")
public String name;
@JsonProperty("sku")
public String sku;
@JsonProperty("stock_status")
public String stockStatus;
@JsonProperty("quantity")
public Integer quantity; 
@JsonProperty("erp_type")
public String erp_type;
@JsonProperty("is_wallmount")
public Boolean is_wallmount;
@JsonProperty("msrp")
public long msrp;
@JsonProperty("price_range")
public PriceRangeDto priceRng;
@JsonProperty("image")
public ImageDto image;
}
