package com.lg.microservice.cart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.lg.microservice.cart.common.config.MagentoClientProps;

@EnableScheduling
@SpringBootApplication
@EnableFeignClients
@EnableConfigurationProperties({
    MagentoClientProps.class
})
public class CartApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CartApiApplication.class, args);
	}

}
