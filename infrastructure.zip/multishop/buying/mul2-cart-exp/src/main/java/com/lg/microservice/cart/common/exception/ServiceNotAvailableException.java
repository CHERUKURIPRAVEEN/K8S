package com.lg.microservice.cart.common.exception;

public class ServiceNotAvailableException extends RuntimeException {

}
