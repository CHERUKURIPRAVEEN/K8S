package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "type", "title", "description", "serviceProductType","sku", "optionItems" })
@Data
public class HandyOptionItemResponse {

	@JsonProperty("type")
	public String type;
	@JsonProperty("title")
	public String title;
	@JsonProperty("subTitle")
	public String subTitle;
	@JsonProperty("description")
	public String description;
	@JsonProperty("serviceProductType")
	public String serviceProductType;
	@JsonProperty("optionItems")
	public List<HandyOptionItem> optionItems = null;
	@JsonProperty("sku")
	public String sku;
	@JsonProperty("dialogContent")
	public List<String> dialogContent;

}