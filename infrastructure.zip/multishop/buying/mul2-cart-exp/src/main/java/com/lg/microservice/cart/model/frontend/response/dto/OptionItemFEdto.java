package com.lg.microservice.cart.model.frontend.response.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"title", "optionItemId", "description", "date", "price",
		"isSelected", "startDate", "endDate", "qty", "maxQty"})
@Data
public class OptionItemFEdto {

	@JsonProperty("title")
	public String title;
	@JsonProperty("optionItemId")
	public String optionItemId;
	@JsonProperty("description")
	public String description;
	@JsonProperty("date")
	public String date;
	@JsonProperty("price")
	public PriceFEdto price;
	@JsonProperty("isSelected")
	public Boolean isSelected;
	@JsonProperty("startDate")
	public String startDate;
	@JsonProperty("endDate")
	public String endDate;
	@JsonProperty("qty")
	public Integer qty;
	@JsonProperty("carrierCode")
	public String carrierCode;
	@JsonProperty("methodCode")
	public String methodCode;
}