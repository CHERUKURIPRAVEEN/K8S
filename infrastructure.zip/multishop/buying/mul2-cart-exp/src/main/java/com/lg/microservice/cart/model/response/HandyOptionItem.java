package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "sku", "maxQty", "quantity", "price" })
@Data
public class HandyOptionItem {

	@JsonProperty("sku")
	public String sku;
	@JsonProperty("maxQty")
	public Integer maxQty;
	@JsonProperty("quantity")
	public Integer quantity;
	@JsonProperty("price")
	public HandyPrice price;
	@JsonProperty("description")
	public String description;
	@JsonProperty("link")
	public String link;
	@JsonProperty("title")
	public String title;
}