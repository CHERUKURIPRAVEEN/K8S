package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CartItemsDTO {

	@JsonProperty("id")
    private String id;
	
	@JsonProperty("product")
    private CartProductDTO product;
	
	@JsonProperty("quantity")
    private String quantity;
}
	

