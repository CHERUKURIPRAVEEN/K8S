package com.lg.microservice.cart.common.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.event.EventListener;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

@Slf4j
@Configuration
@Component
@PropertySource("classpath:application.yml")
public class ApplicationPropertiesConfig {

        @Autowired
        private Environment env;

        @EventListener(ApplicationReadyEvent.class)
        public void printProperties() {

                StringBuilder currentEnvironmentBuilder = new StringBuilder();
                currentEnvironmentBuilder.append("=====Current Environment Info====spring:config:activate:on-profile:\"");
                currentEnvironmentBuilder.append(env.getProperty("spring.profiles.active"));
                currentEnvironmentBuilder.append(" server:port:");
                currentEnvironmentBuilder.append(env.getProperty("server.port"));
                currentEnvironmentBuilder.append(" servlet:context-path:");
                currentEnvironmentBuilder.append(env.getProperty("server.servlet.context-path"));
                currentEnvironmentBuilder.append(" magento:url:");
                currentEnvironmentBuilder.append(env.getProperty("magento.url"));
                currentEnvironmentBuilder.append(" content:stack: ");
                currentEnvironmentBuilder.append(env.getProperty("content.stack"));
                currentEnvironmentBuilder.append(" content:locale: ");
                currentEnvironmentBuilder.append(env.getProperty("content.locale"));
                currentEnvironmentBuilder.append(" storeconfig:url:");
                currentEnvironmentBuilder.append(env.getProperty("storeconfig.url"));
                currentEnvironmentBuilder.append(" translation:url: ");
                currentEnvironmentBuilder.append(env.getProperty("translation.url"));
                currentEnvironmentBuilder.append(" stack:api:url: ");
                currentEnvironmentBuilder.append(env.getProperty("translation.stack.api.url"));
                currentEnvironmentBuilder.append(" group:api:url: ");
                currentEnvironmentBuilder.append(env.getProperty("translation.stack.group.api.url"));
                currentEnvironmentBuilder.append(" message:api:url: ");
                currentEnvironmentBuilder.append(env.getProperty("translation.message.api.url"));
                currentEnvironmentBuilder.append(" zipcode:usps:url: ");
                currentEnvironmentBuilder.append(env.getProperty("zipcode.usps.url"));
                currentEnvironmentBuilder.append(" zipcode:usps:validate:url: ");
                currentEnvironmentBuilder.append(env.getProperty("zipcode.usps.validate.url"));

                StringBuilder commonEnvironmentBuilder = new StringBuilder();
                commonEnvironmentBuilder.append("=====Common Environment Info====feign:client:config:default:connectTimeout: ");
                commonEnvironmentBuilder.append(env.getProperty("feign.client.config.default.connectTimeout"));
                commonEnvironmentBuilder.append(" readTimeout: ");
                commonEnvironmentBuilder.append(env.getProperty("feign.client.config.default.readTimeout"));
                commonEnvironmentBuilder.append(" loggerLevel: ");
                commonEnvironmentBuilder.append(env.getProperty("feign.client.config.default.loggerLevel"));
                commonEnvironmentBuilder.append(" logging:level:com:lg:microservice:cart:feign: ");
                commonEnvironmentBuilder.append(env.getProperty("logging.level.com.lg.microservice.cart.feign"));
                commonEnvironmentBuilder.append(" trace-log-aspect:controller:enabled: ");
                commonEnvironmentBuilder.append(env.getProperty("trace-log-aspect.controller.enabled"));
                commonEnvironmentBuilder.append(" prefix: ");
                commonEnvironmentBuilder.append(env.getProperty("trace-log-aspect.controller.prefix"));
                commonEnvironmentBuilder.append(" service:enabled: ");
                commonEnvironmentBuilder.append(env.getProperty("trace-log-aspect.service.enabled"));
                commonEnvironmentBuilder.append(" prefix: ");
                commonEnvironmentBuilder.append(env.getProperty("trace-log-aspect.service.prefix"));
                commonEnvironmentBuilder.append(" persistent:enabled: ");
                commonEnvironmentBuilder.append(env.getProperty("trace-log-aspect.persistent.enabled"));
                commonEnvironmentBuilder.append(" prefix: ");
                commonEnvironmentBuilder.append(env.getProperty("trace-log-aspect.persistent.prefix"));
                commonEnvironmentBuilder.append(" springdoc:api-docs:enabled: ");
                commonEnvironmentBuilder.append(env.getProperty("springdoc.api-docs.enabled"));
                commonEnvironmentBuilder.append(" path: ");
                commonEnvironmentBuilder.append(env.getProperty("springdoc.api-docs.path"));
                commonEnvironmentBuilder.append(" swagger-ui:path: ");
                commonEnvironmentBuilder.append(env.getProperty("springdoc.swagger-ui.path"));

                log.info(String.valueOf(currentEnvironmentBuilder));
                log.info(String.valueOf(commonEnvironmentBuilder));
        }
}
