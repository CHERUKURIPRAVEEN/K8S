package com.lg.microservice.cart.model.frontend.response.dto;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"type",
"variant",
"icon",
"title",
"subTitle",
"description",
"isExpanded",
"price",
"optionItems"
})
@Data
public class ShipmentItemOptionFEdto {

@JsonProperty("type")
public String type;
@JsonProperty("title")
public String title;
@JsonProperty("description")
public String description;
@JsonProperty("price")
public PriceFEdto price;
@JsonProperty("optionItems")
public List<OptionItemFEdto> optionItems = null;

}

