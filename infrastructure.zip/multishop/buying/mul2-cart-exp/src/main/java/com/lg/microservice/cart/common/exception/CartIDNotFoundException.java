package com.lg.microservice.cart.common.exception;

import lombok.Data;

@Data
public class CartIDNotFoundException extends RuntimeException {

	String message;

	public CartIDNotFoundException(String message) {
		this.message = message;
	}

	public CartIDNotFoundException() {
		// TODO Auto-generated constructor stub
	}
}
