package com.lg.microservice.cart.model.frontend.response.dto;

import lombok.Data;

@Data
public class DSDates {
	public String date;
}
