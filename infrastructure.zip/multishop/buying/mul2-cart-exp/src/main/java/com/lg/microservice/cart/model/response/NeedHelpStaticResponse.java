package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class NeedHelpStaticResponse {

	@JsonProperty("heading")
	public String heading;

	@JsonProperty("faq")
	public FrequentlyAskedQuestions faq;
	
	
}
