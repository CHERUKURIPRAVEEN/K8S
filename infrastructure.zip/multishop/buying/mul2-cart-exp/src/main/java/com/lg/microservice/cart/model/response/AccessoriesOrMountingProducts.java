package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class AccessoriesOrMountingProducts {
	
	 
    @JsonProperty("items")
    private List<ProductItems> items;

}
