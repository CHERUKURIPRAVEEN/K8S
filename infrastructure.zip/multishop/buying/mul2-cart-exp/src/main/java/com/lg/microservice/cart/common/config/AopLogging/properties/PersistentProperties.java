package com.lg.microservice.cart.common.config.AopLogging.properties;

import com.lg.microservice.cart.constant.LogConstants;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(
    prefix = "trace-log-aspect.persistent"
)
@Data
public class PersistentProperties {
    private boolean enabled = false;
    private String prefix = LogConstants.PER_PREFIX;
    private String exclude;
}
