package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.dto.magento.MagentoError;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class HandyOptionItemResponseMagento {

	 	@JsonProperty("products")
	    private HandyProducts products;
	    
	    @JsonProperty("statusCode")
	    private Integer status;
	    
	    @JsonProperty("errors")
	    private List<MagentoError> errors;
}
