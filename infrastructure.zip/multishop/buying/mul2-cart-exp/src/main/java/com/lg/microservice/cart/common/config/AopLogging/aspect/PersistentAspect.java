package com.lg.microservice.cart.common.config.AopLogging.aspect;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import com.lg.microservice.cart.common.config.AopLogging.context.TraceContext;
import com.lg.microservice.cart.constant.LogConstants;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Aspect
@Data
@Slf4j
public class PersistentAspect {
    private boolean enabled = false;
    private String prefix = LogConstants.PER_PREFIX;
    private List<String> exclude = new ArrayList<>();

    @Around("within(@org.springframework.stereotype.Repository *)" )
    public Object doPersistentTraceLogging(ProceedingJoinPoint joinPoint) throws Throwable {

        Object result = null;

        String className = joinPoint.getSignature().getDeclaringTypeName();
        if (enabled && !exclude.contains(className)){

            String methodName = joinPoint.getSignature().toLongString();

            StringBuffer beforeMethodLog = new StringBuffer();
            beforeMethodLog.append("\n");
            beforeMethodLog.append(prefix + " Class : " + className + "\n");
            beforeMethodLog.append(prefix + " Method : " + methodName + "\n");

            Object[] obj = joinPoint.getArgs();
            int argumentIndex = 0;
            for(Object argument : obj){
                beforeMethodLog.append(prefix + " Query Argument [" + argumentIndex++ + "]: " + argument + "\n");
            }
            log.info(beforeMethodLog.toString());
            long beforeTime = System.currentTimeMillis();

            //Query 
            result = joinPoint.proceed();

            long afterTime = System.currentTimeMillis();
            StringBuffer afterMethodLog = new StringBuffer();
            afterMethodLog.append("\n");
            afterMethodLog.append(prefix + " Query Lap Time : " + (afterTime - beforeTime) + " ms\n");

            //QueryLoggingInterceptor
            Map<?, ?> map = TraceContext.local.get();
            if(map != null){
                afterMethodLog.append(prefix + " Query : \n\t" + map.get("sql") + "\n");
                if(map.get("paramInfo") != null){
                    afterMethodLog.append(prefix + " Binding Params : \n\t" + map.get("paramInfo") + "\n");
                }
            } else {
                afterMethodLog.append("No queries were run.");
            }

            log.info(afterMethodLog.toString());
        } else {
            result = joinPoint.proceed();
        }
        return result;
    }

    @AfterThrowing(pointcut = "within(@org.springframework.stereotype.Repository *)" , throwing = "exception")
    public void doPersistentErrorTraceLogging(JoinPoint thisJoinPoint, Exception exception) throws Exception {
        if(enabled){
            if(TraceContext.local.get() != null){
                String sql = (String) TraceContext.local.get().get("sql");
                log.info("\n" + prefix + " Error Query : \n\t" + sql);
            }
            log.info("\n" + prefix + " Error Log : " + exception.getMessage());
        }
        throw exception;
    }

    /**
     *
     *
     * @param thisJoinPoint
     */
    @After("within(@org.springframework.stereotype.Repository *)" )
    public void doPersistentFinallyTraceLogging(JoinPoint thisJoinPoint){
        if(enabled){
            TraceContext.local.remove();
        }
    }
}
