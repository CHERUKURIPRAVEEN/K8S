package com.lg.microservice.cart.model.dto.magento;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"setDeliveryDate"})
@Data
public class DSSelectedDateResponse {
	@JsonProperty("setDeliveryDate")
	public SetDeliveryDate setDeliveryDate;
	@JsonProperty("statusCode")
	private Integer status;
	@JsonProperty("errors")
	private List<MagentoError> errors;
}