package com.lg.microservice.cart.model.frontend.response;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.lg.microservice.cart.model.frontend.response.dto.ShipmentItemFEDto;
import com.lg.microservice.cart.model.frontend.response.dto.StatusDto;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cartId",
"shipmentItems",
"status"
})
@Data
public class ShipmentFEResponse {

@JsonProperty("cartId")
public String cartId;
@JsonProperty("shipmentItems")
public List<ShipmentItemFEDto> shipmentItems = null;
@JsonProperty("status")
public StatusDto status;

}