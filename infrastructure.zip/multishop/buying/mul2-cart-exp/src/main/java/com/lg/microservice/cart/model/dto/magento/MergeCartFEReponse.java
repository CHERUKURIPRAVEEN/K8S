package com.lg.microservice.cart.model.dto.magento;

import lombok.Data;

@Data
public class MergeCartFEReponse {

	private String status;
	private String statusCode;
	private String message;
	private boolean isGuestCartEmpty;
	private String magentoResponse;
}