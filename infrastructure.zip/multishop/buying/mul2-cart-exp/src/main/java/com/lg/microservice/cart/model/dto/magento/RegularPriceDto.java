package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)

@Data
public class RegularPriceDto {

	@JsonProperty("currency")
	public String currency;
	@JsonProperty("value")
	public Double value;

}
