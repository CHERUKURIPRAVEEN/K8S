package com.lg.microservice.cart.model.request;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"deliveryOptions",
"subscriptionOption",
"handWallMountOption",
"espOption"
})
@Data
public class UpdateOptionsRequestBody {

    @JsonProperty("deliveryOption")
    public List<DeliveryOptionsRequestBody> deliveryOption;

    @JsonProperty("subscriptionOption")
    public List<SubscrptionOtpionRequestBody> subscriptionOption;

    @JsonProperty("handWallMountOption")
    public List<HandWallMountOptionRequestBody> handWallMountOption;

    @JsonProperty("espOption")
    public List<EspOptionRequestBody> espOption;

    @JsonProperty("action")
    @Schema(description = "action is optional")
    private String action;

}