package com.lg.microservice.cart.model.frontend.response.dto;

import lombok.Data;

@Data
public class TotalOrderSavingDto {

	public double value;
	public String displayText;
}
