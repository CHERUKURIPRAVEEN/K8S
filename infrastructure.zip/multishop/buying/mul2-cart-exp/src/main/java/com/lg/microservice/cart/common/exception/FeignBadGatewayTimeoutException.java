package com.lg.microservice.cart.common.exception;

public class FeignBadGatewayTimeoutException extends RuntimeException {

}
