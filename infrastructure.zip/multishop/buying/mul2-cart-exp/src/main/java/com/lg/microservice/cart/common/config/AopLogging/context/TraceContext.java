package com.lg.microservice.cart.common.config.AopLogging.context;

import java.util.Map;

public class TraceContext {
    public static ThreadLocal<Map<String,String>> local = new ThreadLocal<Map<String,String>>();
}
