package com.lg.microservice.cart.feign;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Objects;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lg.microservice.cart.model.response.GraphqlResponse;

import feign.FeignException;
import feign.Response;
import feign.Util;
import feign.codec.DecodeException;

@Slf4j
public class MagentoClientDecoder extends SpringDecoder {

  private final ObjectMapper objectMapper;

  public MagentoClientDecoder(ObjectFactory<HttpMessageConverters> messageConverters,
      ObjectMapper objectMapper) {
    super(messageConverters);
    this.objectMapper = objectMapper;
  }

  @Override
  public Object decode(Response response, Type type)
      throws IOException, DecodeException, FeignException {
    HttpStatus responseStatus = HttpStatus.valueOf(response.status());
    String bodyStr = null;
    try {
     bodyStr = Util.toString(response.body().asReader(Util.UTF_8));
    }
    catch (Exception e) {
     log.info("Cart MS MagentoClientDecoder----> "+e);
    }
    if (responseStatus.is2xxSuccessful()) {
      GraphqlResponse responseData = objectMapper.readValue(bodyStr, GraphqlResponse.class);
      try {
        Class<?> clazz = Class.forName(type.getTypeName());
        if (Objects.isNull(responseData)) {
          throw new DecodeException(500, "Unknown Error", response.request());
        } else if (Objects.nonNull(responseData.getErrors())
            && !responseData.getErrors().isEmpty() && Objects.nonNull(responseData.getErrors().get(0).getMessage())) {
          return responseData;
        }
        return objectMapper.convertValue(responseData, clazz);
      } catch (ClassNotFoundException e) {
        throw new DecodeException(response.status(),
            "type is not an instance of Class or ParameterizedType: " + type,
            response.request());
      }
    }
    throw new DecodeException(response.status(), bodyStr, response.request());
  }
}
