package com.lg.microservice.cart.model.dto.magento;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"applied_taxes",
"discounts",
"grand_total",
"subtotal_excluding_tax",
"subtotal_including_tax",
"subtotal_with_discount_excluding_tax"
})
@Data
public class PricesOrderSummaryDto {

@JsonProperty("applied_taxes")
public List<AppliedTaxOrderSummaryDto> appliedTaxes = null;
@JsonProperty("discounts")
public List<DiscountDto> discounts;
@JsonProperty("grand_total")
public GrandTotalOrderSummaryDto grandTotal;
@JsonProperty("subtotal_excluding_tax")
public SubtotalExcludingTaxOrderSummaryDto subtotalExcludingTax;
@JsonProperty("subtotal_including_tax")
public SubtotalIncludingTaxOrderSummaryDto subtotalIncludingTax;
@JsonProperty("subtotal_with_discount_excluding_tax")
public SubtotalWithDiscountExcludingTaxOrderSummaryDto subtotalWithDiscountExcludingTax;

  
}
