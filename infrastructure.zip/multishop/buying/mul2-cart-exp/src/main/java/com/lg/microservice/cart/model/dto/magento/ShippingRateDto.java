package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"carrier", "carrier_title", "method", "method_title",
		"cost", "price", "from_day", "to_day", "selected"})

@Data
public class ShippingRateDto {
	@JsonProperty("identifier")
	public String identifier;
	@JsonProperty("carrier")
	public String carrier;
	@JsonProperty("carrier_title")
	public String carrierTitle;
	@JsonProperty("method")
	public String method;
	@JsonProperty("method_title")
	public String methodTitle;
	@JsonProperty("cost")
	public String cost;
	@JsonProperty("price")
	public Double price;
	@JsonProperty("from_day")
	public Integer fromDay;
	@JsonProperty("to_day")
	public Integer toDay;
	@JsonProperty("selected")
	public Boolean selected;
	@JsonProperty("est_shipping_text")
	public String estShippingText;
	@JsonProperty("est_shipping_date")
	public String estShppingDate;
}
