package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class HandyProducts {
	
	 
    @JsonProperty("items")
    private List<HandyProductItems> items;

}
