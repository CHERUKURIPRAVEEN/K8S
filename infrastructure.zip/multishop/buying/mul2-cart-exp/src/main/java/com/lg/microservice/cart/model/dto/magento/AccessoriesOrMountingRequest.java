package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AccessoriesOrMountingRequest {

	
	@NotBlank
	private String token;
	
	@NotBlank
	private String sku;

	private String store;

	public static AccessoriesOrMountingRequest of(String  token, String sku, String store) {
	
		Objects.requireNonNull(token);
		Objects.requireNonNull(sku,store);
		return new AccessoriesOrMountingRequest(token, sku,store);
	}

}
