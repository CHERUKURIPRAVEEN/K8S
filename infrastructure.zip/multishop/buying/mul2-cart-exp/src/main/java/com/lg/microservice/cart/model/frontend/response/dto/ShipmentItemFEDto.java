package com.lg.microservice.cart.model.frontend.response.dto;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"shipmentId",
"status",
"cartItems",
"shipmentItemOptions"
})
@Data
public class ShipmentItemFEDto {

@JsonProperty("shipmentId")
public String shipmentId;
@JsonProperty("shipmentGroupId")
public Integer shipmentGroupId;
@JsonProperty("status")
public StatusDto status;
@JsonProperty("cartItems")
public List<CartItemFEdto> cartItems;
@JsonProperty("shipmentItemOptions")
public List<ShipmentItemOptionFEdto> shipmentItemOptions;

}