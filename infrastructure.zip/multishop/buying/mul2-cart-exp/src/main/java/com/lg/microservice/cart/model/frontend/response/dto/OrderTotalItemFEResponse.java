package com.lg.microservice.cart.model.frontend.response.dto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"title", "value", "subTitle"})
@Data
public class OrderTotalItemFEResponse {
	@JsonProperty("title")
	public String title;
	@JsonProperty("value")
	public Double value;
	@JsonProperty("subTitle")
	public String subTitle;
	@JsonProperty("displayText")
	public String displayText;

}