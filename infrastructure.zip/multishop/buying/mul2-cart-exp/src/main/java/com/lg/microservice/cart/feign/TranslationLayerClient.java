package com.lg.microservice.cart.feign;

import java.util.List;
import java.util.Map;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import com.lg.microservice.cart.model.response.ResponseData;

@FeignClient(name = "mul2-localization", url = "${translation.url}")
public interface TranslationLayerClient {

	@GetMapping("${translation.stack.api.url}")
	public ResponseEntity<ResponseData> generateContentStack(
			@RequestHeader(name = "stackList") List<String> stackList,
			@RequestHeader(name = "locale") String locale,
			@RequestHeader(name = "store") String storeCode);

	@PostMapping("${translation.message.api.url}")
	public ResponseEntity<ResponseData> generateContentMessage(
			@RequestHeader(name = "keyList") List<String> keyList,
			@RequestHeader(name = "locale") String locale);

	@PostMapping("${translation.message.api.url}")
	public ResponseEntity<ResponseData> generateContentMessage(
			@RequestHeader(name = "keyList") List<String> keyList,
			@RequestHeader(name = "locale") String locale,
			@RequestBody(required = false) Map<String, List<String>> inputMap);
	
	@GetMapping("${translation.stack.group.api.url}")
	public Map<String, Map<String, String>> generateContentStackGroup(
			@RequestHeader(name = "stackList") List<String> stackList,
			@RequestHeader(name = "locale") String locale,
			@RequestHeader(name = "store") String storeCode);
}
