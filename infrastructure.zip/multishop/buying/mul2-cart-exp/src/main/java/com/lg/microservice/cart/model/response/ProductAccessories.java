package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ProductAccessories {

	@JsonProperty("name")
	private String name;

	@JsonProperty("sku")
	private String sku;

	@JsonProperty("erp_type")
	private String erpType;

	@JsonProperty("stock_status")
	private String stockStatus;
	
	@JsonProperty("pdp_url")
	private String pdpUrl;

	@JsonProperty("quantity")
	private String quantity;

	@JsonProperty("is_wallmount")
	private String isWallmount;

	@JsonProperty("msrp")
	private Double msrp;

	@JsonProperty("price_range")
	private PriceRange priceRange;

	@JsonProperty("image")
	private ProductImage image;

	@JsonProperty("contract_term_month")
	private String contract_term_month;

}
