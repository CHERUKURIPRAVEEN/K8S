package com.lg.microservice.cart.model.dto.magento;

import lombok.Data;

@Data
public class StockWarehouseCodes {
	public String code;
	public Integer qty;

}
