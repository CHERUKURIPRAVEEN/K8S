package com.lg.microservice.cart.model.request;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CartCouponRequestBody {

  @JsonProperty("couponCode")
  @Schema(description = "Coupon code should not be blank")
  private String couponCode;

  @JsonProperty("action")
  @Schema(description = "action is optional")
  private String action;
 
}
