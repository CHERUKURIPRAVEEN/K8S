package com.lg.microservice.cart.model.request;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class GeoZipcodeRequest {

	@NotBlank(message = "Zipcode must not be blank")
	private String zipcode;

	private String countrycode;

	private String city;

	private String region;
}
