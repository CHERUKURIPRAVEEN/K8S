package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.response.CartItemResponse;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class MergeCartResponse extends CartItemResponse{

	@JsonProperty("merged")
	private Boolean merged;

	@JsonProperty("mixed")
	private Boolean mixed;

	@JsonProperty("oldCart")
	private CartDto oldCart;

}
