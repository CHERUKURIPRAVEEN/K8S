package com.lg.microservice.cart.common.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Reason {

    SUCCESS(200, "Success"),
    UNEXPECTED(1001, "Unexpected exception"),
    NOT_IN_COVERAGE_AREA(1003, "Cannot delivery product to provided Zip area"),
    MAGENTO_UNAVAILABLE(1005, "Backend service unavailable"),
    INVALID_REQUEST_PARAM(1008, "Invalid request param provided"),
	INVALID_DATA(1004, "Please enter valid IP or LatLng Details"),
	INVALID_ZIPCODE(1002, "Zipcode cannot be blank"),
	INVALID_RESPONSE(1005, "Could not get the valid response form Google API"),
	NOT_AUTHORIZED(1006, "The user is not authorized to make the request."),
	INVALID_CARTID(1007, "Cart id cannot be blank"),
	INVALID_TOKEN(1008, "Token cannot be blank"),
	SSO_VALIDATION_FAILED(500, "SSO validation Failed"),
	INVALID_LATLNG(1009, "LatLng cannot be blank"), 
	NO_ZIPCODE_FOUND(2000, "No zipcode found for the given lat and lng");


    private final int code;
    private final String message;

}
