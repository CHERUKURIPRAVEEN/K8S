package com.lg.microservice.cart.model.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cartItemId",
"quantity",
"carrierCode",
"methodCode",
"deliveryOptions"
})
@Data
public class DeliveryOptionsRequestBody {
@JsonProperty("cartItemId")
public Integer cartItemId;
@JsonProperty("quantity")
public Integer quantity;
@JsonProperty("carrierCode")
public String carrierCode;
@JsonProperty("methodCode")
public String methodCode;
@JsonProperty("deliveryOptions")
public DeliveryOptionTypeRequestBody deliveryOptions;

}