package com.lg.microservice.cart.common.exception;

public class MagentoInternalServerException extends RuntimeException {

}
