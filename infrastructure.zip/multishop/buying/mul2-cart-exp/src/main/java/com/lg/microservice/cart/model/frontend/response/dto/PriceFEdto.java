package com.lg.microservice.cart.model.frontend.response.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"currency",
"msrp",
"finalPrice",
"discount"
})
@Data
public class PriceFEdto {

@JsonProperty("currency")
public String currency;

@JsonProperty("msrp")
public PriceTypeDto msrp;

@JsonProperty("finalPrice")
public PriceTypeDto finalPrice;

@JsonProperty("discount")
public PriceTypeDto discount;

@JsonProperty("regularPrice")
public PriceTypeDto regularPrice;


}