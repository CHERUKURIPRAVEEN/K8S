package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;
import javax.validation.constraints.NotBlank;
import com.lg.microservice.cart.model.request.UpdateCartItemRequestBody;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class UpdateItemsToCartRequest {

    @NotBlank
    private String cartId;
    
    @NotBlank
    private String store;
    
    @NotBlank
    private String token;
    
    @NotBlank
    private UpdateCartItemRequestBody reqBody;

    public static UpdateItemsToCartRequest of(String cartId, String store, String token, UpdateCartItemRequestBody patchItemRequestBody) {
        Objects.requireNonNull(cartId, store);
        Objects.requireNonNull(patchItemRequestBody);
        Objects.requireNonNull(token);
        
        return new UpdateItemsToCartRequest(cartId, store, token, patchItemRequestBody);
    }
}
