//package com.lg.microservice.cart.model.response;
//
//import java.util.List;
//import com.fasterxml.jackson.annotation.JsonInclude;
//import com.fasterxml.jackson.annotation.JsonProperty;
//import com.fasterxml.jackson.annotation.JsonPropertyOrder;
//import com.lg.microservice.cart.model.response.dto.ShipmentItemDto;
//import com.lg.microservice.cart.model.response.dto.StatusDto;
//
//@JsonInclude(JsonInclude.Include.NON_NULL)
//@JsonPropertyOrder({
//"cartId",
//"shipmentItems",
//"status"
//})
//public class CartSummaryResponse {
//  @JsonProperty("cartId")
//  public String cartId;
//  @JsonProperty("shipmentItems")
//  public List<ShipmentItemDto> shipmentItems = null;
//  @JsonProperty("status")
//  public StatusDto status;
//}
