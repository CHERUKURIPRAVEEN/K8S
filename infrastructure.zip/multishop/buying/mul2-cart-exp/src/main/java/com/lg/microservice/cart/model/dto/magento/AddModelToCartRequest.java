package com.lg.microservice.cart.model.dto.magento;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.validation.constraints.NotBlank;
import java.util.Objects;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class AddModelToCartRequest {

    @NotBlank
    private String cartId;

    @NotBlank
    private String sku;

    @NotBlank
    private Boolean isHandy;

    @NotBlank
    private String token;

    @NotBlank
    private String store;

    public static AddModelToCartRequest of(String cartId, String sku, Boolean isHandy, String token, String store) {
        Objects.requireNonNull(store, token);
        Objects.requireNonNull(cartId, sku);
        return new AddModelToCartRequest(cartId, sku, isHandy, token, store);
    }
}
