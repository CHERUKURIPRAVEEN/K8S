package com.lg.microservice.cart.model.dto;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
public class ResponseData {
    private String successOrNot;
    private int statusCode;
    private String message;
    private Object data;

    public ResponseData(String successOrNot, int statusCode, String message, Object data) {
        this.successOrNot = successOrNot;
        this.statusCode = statusCode;
        this.message = message;
        this.data = data;
    }

}
