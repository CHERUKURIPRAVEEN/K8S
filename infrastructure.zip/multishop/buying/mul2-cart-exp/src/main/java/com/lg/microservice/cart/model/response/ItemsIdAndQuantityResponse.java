package com.lg.microservice.cart.model.response;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.dto.magento.MagentoError;
import lombok.Data;

@Data
public class ItemsIdAndQuantityResponse {

   public CartItemsIdAndQuantityResponse cart;
   
   @JsonProperty("statusCode")
   private Integer status;
   
   @JsonProperty("errors")
   private List<MagentoError> errors;
   
}
