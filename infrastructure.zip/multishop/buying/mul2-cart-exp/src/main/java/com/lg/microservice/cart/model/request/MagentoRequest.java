package com.lg.microservice.cart.model.request;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class MagentoRequest {

	@NotBlank
	private String cartid;

	@NotBlank
	private String zipcode;
	
	@NotBlank
	private String token;
	
	private String countrycode;
	private String city;
	private String region;
	private String store;

	public static MagentoRequest of(String cartid, String zipcode, String token) {
		Objects.requireNonNull(cartid);
		Objects.requireNonNull(zipcode);
		return new MagentoRequest(cartid, zipcode, token);
	}

	public MagentoRequest(String cartIdVal, String zipcode, String token) {
		this.cartid = cartIdVal;
		this.zipcode = zipcode;
		this.token = token;
	}
	
	public static MagentoRequest of(String cartid, String zipcode, String token, String countrycode, String city, String region, String store) {
		Objects.requireNonNull(cartid);
		Objects.requireNonNull(zipcode);
		return new MagentoRequest(cartid, zipcode, token, countrycode, city, region, store);
	}

	public MagentoRequest(String cartIdVal, String zipcode, String token, String countrycode, String city, String region, String store) {
		this.cartid = cartIdVal;
		this.zipcode = zipcode;
		this.token = token;
		this.city = city;
		this.countrycode = countrycode;
		this.region = region;
		this.store = store;
	}
}