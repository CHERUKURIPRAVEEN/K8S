package com.lg.microservice.cart.model.response;

import java.util.List;

import com.lg.microservice.cart.model.dto.magento.MagentoError;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GraphqlResponse {

  private Object data;

  private List<MagentoError> errors;
  
  private Integer statusCode;
}
