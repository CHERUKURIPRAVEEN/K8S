package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
  public class RemoveCartItemDTO{
    
    @JsonProperty("email")
    private String email;
    
    @JsonProperty("id")
    private String id;
    
    @JsonProperty("is_virtual")
    private String isVirtual;
    
    @JsonProperty("total_quantity")
    private String totalQuantity;
  }