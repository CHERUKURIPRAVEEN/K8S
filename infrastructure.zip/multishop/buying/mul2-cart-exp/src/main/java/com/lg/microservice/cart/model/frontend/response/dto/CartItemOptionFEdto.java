package com.lg.microservice.cart.model.frontend.response.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"type", "isSelectable", "description", "optionItems",
		"startDate", "instructionList"})
@Data
public class CartItemOptionFEdto {
	@JsonProperty("title")
	public String title;
	@JsonProperty("type")
	public String type;
	@JsonProperty("isSelectable")
	public Boolean isSelectable;
	@JsonProperty("description")
	public String description;
	@JsonProperty("optionItems")
	public List<OptionItemFEdto> optionItems = null;
	@JsonProperty("startDate")
	public String startDate;
	@JsonProperty("instructionList")
	public List<String> instructionList = null;
	@JsonProperty("link")
	public String link;
	@JsonProperty("additionalDiscountDescription")
	public String additionalDiscountDescription;
}