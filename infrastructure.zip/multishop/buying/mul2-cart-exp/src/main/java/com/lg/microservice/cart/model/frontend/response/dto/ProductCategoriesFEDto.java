package com.lg.microservice.cart.model.frontend.response.dto;

import lombok.Data;

@Data
public class ProductCategoriesFEDto {

	public Integer id;
	public String name;
}
