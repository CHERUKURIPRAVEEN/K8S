package com.lg.microservice.cart.model.dto.magento;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"amount",
"label"
})
@Data
public class DiscountDto {

@JsonProperty("amount")
public AmountOrderSummaryDTO amount;
@JsonProperty("label")
public String label;

}