package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.response.Cart;

import lombok.Data;

@Data
public class CouponResponse{
  
  @JsonProperty("cart")
  private Cart cart;
}