package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lg.microservice.cart.model.response.CartResponse;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CartItems {

    @JsonProperty("product")
    private AddToProductModel product;

    @JsonProperty("quantity")
    private String quantity;
}
