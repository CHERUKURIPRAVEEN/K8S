package com.lg.microservice.cart.model.response;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Holidays {
	
	@JsonProperty("label")
	private String label;
	
	@JsonProperty("days")
	private List<String> days;
}
