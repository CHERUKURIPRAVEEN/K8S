package com.lg.microservice.cart.common.exception;

import lombok.Getter;

@Getter
public class BaseException extends RuntimeException {

    private final Reason reason;

    public BaseException(Reason reason) {
        this.reason = reason;
    }

    public BaseException(Reason reason, String message) {
        super(message);
        this.reason = reason;
    }

}
