package com.lg.microservice.cart.model.request;

import javax.validation.constraints.NotBlank;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CartItemRequestBody {

  @JsonProperty("itemId")
  @Schema(description = "product SKU id should not be blank")
  private String itemId;
  
  @JsonProperty("handyParentItemId")
  private String handyParentItemId;

  @JsonProperty("zipCode")
  private String zipCode;

}
