package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class SelectedShippingMethod {

    @JsonProperty("amount")
    public AmountOrderSummaryDTO amount;
}
