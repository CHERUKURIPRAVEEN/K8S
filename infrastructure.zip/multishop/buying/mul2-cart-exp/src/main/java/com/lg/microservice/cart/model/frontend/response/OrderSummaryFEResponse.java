package com.lg.microservice.cart.model.frontend.response;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.lg.microservice.cart.model.frontend.response.dto.OrderSummaryItemFEResponse;
import com.lg.microservice.cart.model.frontend.response.dto.OrderTotalItemFEResponse;
import com.lg.microservice.cart.model.frontend.response.dto.PromoFEResponse;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"orderSummaryItems",
"orderTotalItems",
"promo"
})
@Data
public class OrderSummaryFEResponse {

@JsonProperty("orderSummaryItems")
public List<OrderSummaryItemFEResponse> orderSummaryItems = null;
@JsonProperty("orderTotalItems")
public List<OrderTotalItemFEResponse> orderTotalItems = null;
@JsonProperty("promo")
public PromoFEResponse promo;


}