package com.lg.microservice.cart.model.frontend.response.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class ServiceProductOptions {

	@JsonProperty("title")
	public String title;
	
	@JsonProperty("subTitle")
	public String subTitle;

	@JsonProperty("description")
	public String description;

	@JsonProperty("childItemId")
	public Integer childItemId;

	@JsonProperty("quantity")
	public Integer quantity;

	@JsonProperty("price")
	public PriceFEdto price;

	@JsonProperty("sku")
	public String sku;

}
