package com.lg.microservice.cart.feign;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import com.lg.microservice.cart.model.request.GraphqlRequestBody;
import com.lg.microservice.cart.model.response.GraphqlResponse;

public interface MagentoServiceClient {

	
	@PostMapping("/graphql")
	GraphqlResponse query(GraphqlRequestBody query, @RequestHeader("Store") String store, @RequestHeader("Authorization") String authorization);

}
