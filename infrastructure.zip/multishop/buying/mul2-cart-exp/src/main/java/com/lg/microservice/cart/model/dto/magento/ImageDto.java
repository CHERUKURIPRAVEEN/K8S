package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"disabled",
"label",
"position",
"url"
})
@Data
public class ImageDto {

  @JsonProperty("disabled")
  public Boolean disabled;
  @JsonProperty("label")
  public String label;
  @JsonProperty("position")
  public Integer position;
  @JsonProperty("url")
  public String url;
  
}
