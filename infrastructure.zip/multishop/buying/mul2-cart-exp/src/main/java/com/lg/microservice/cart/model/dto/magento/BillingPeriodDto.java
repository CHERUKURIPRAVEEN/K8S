package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class BillingPeriodDto {
  @JsonProperty("id")
  public String id;
  @JsonProperty("intervalLabel")
  public String intervalLabel;
  @JsonProperty("intervalType")
  public String intervalType;
  @JsonProperty("numberOfInterval")
  public Integer numberOfInterval;
  
}
