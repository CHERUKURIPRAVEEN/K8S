package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.lg.microservice.cart.model.dto.magento.PriceCurrencyDTO;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"currency", "finalPrice"})
@Data
public class HandyPrice {

	@JsonProperty("currency")
	public String currency;
	@JsonProperty("finalPrice")
	public PriceCurrencyDTO finalPrice;

}