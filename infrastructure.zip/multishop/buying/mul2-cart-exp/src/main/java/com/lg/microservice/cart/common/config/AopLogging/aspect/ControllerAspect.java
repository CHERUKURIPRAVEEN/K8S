package com.lg.microservice.cart.common.config.AopLogging.aspect;


import java.io.Closeable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.ui.Model;
import org.springframework.validation.DataBinder;
import org.springframework.validation.Errors;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.lg.microservice.cart.constant.LogConstants;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Aspect
@Slf4j
@Data
public class ControllerAspect {

    private static final String PARAM_SEPARATE = " Input Parameter Value : ";
    private String prefix = LogConstants.CTR_PREFIX;
    private boolean enabled = false;
    private List<String> exclude = new ArrayList<>();

    @Around("within(@org.springframework.web.bind.annotation.RestController *) || within(@org.springframework.stereotype.Controller *)")
    public Object controllerLogging(ProceedingJoinPoint joinPoint) throws  Throwable{
        ServletRequestAttributes sra = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = sra.getRequest();

        Object result = null;

        String className = joinPoint.getSignature().getDeclaringTypeName();
        if (enabled && !exclude.contains(className)){
            String methodName = joinPoint.getSignature().toLongString();
            StringBuilder beforeMethodLog = new StringBuilder();
            String modelName = "";
            Gson gson = new GsonBuilder().setPrettyPrinting().create();

            beforeMethodLog.append("\n");
            beforeMethodLog.append(prefix + " RequestMapping : " + request.getRequestURI() + "\n");
            beforeMethodLog.append(prefix + " Class : " + className + "\n");
            beforeMethodLog.append(prefix + " Method : " + methodName + "\n");

            Object[] obj = joinPoint.getArgs();

            for( int inx = 0; inx < obj.length ; inx++ ){
                if(obj[inx] == null
                        || obj[inx] instanceof ServletRequest || obj[inx] instanceof DataBinder
                        || obj[inx] instanceof HttpSession || obj[inx] instanceof RequestAttributes
                        || obj[inx] instanceof Cloneable || obj[inx] instanceof Closeable
                        || obj[inx] instanceof Map || obj[inx] instanceof Model
                        || obj[inx] instanceof Errors || obj[inx] instanceof SessionStatus
                        || obj[inx] instanceof ServletResponse
                ) {

                } else if(obj[inx] instanceof String){
                    beforeMethodLog.append(prefix + PARAM_SEPARATE + obj[inx].toString() + "\n");

                } else if(obj[inx] instanceof Integer){
                    beforeMethodLog.append(prefix + PARAM_SEPARATE + Integer.parseInt(obj[inx].toString()) + "\n");

                } else if(obj[inx] instanceof List){
                    List<?> list = (List<?>) obj[inx];
                    Class<? extends Object> cls = list.get(0).getClass();
                    modelName = cls.getName();
                    beforeMethodLog.append(prefix + PARAM_SEPARATE + modelName + "[" + (list.size() - 1) + "]\n");
                    for(int jnx = 0 ; jnx < list.size() ; jnx++){
                        String clsInfo = gson.toJson(list.get(jnx));
                        beforeMethodLog.append(clsInfo + "\n");
                    }
                } else {

                    Class<? extends Object> cls = obj[inx].getClass();
                    modelName = cls.getName();
                    beforeMethodLog.append(prefix + PARAM_SEPARATE + modelName + "\n");
                    String clsInfo = gson.toJson(obj[inx]);
                    beforeMethodLog.append(clsInfo + "\n");
                }
            }

            log.info(beforeMethodLog.toString());

            result = joinPoint.proceed();

            StringBuilder afterMethodLog = new StringBuilder();
            afterMethodLog.append("\n");

            if(result != null){
                afterMethodLog.append(prefix + " Target : " + result.toString() + "\n");
            }

            log.info(afterMethodLog.toString());

        } else {
            result = joinPoint.proceed();
        }

        return result;
    }

}
