package com.lg.microservice.cart.model.request;

import java.util.Collections;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GraphqlRequestBody {

  private String query;
  private Object variables;

  public GraphqlRequestBody(String query) {
    this(query, Collections.emptyMap());
  }
}
