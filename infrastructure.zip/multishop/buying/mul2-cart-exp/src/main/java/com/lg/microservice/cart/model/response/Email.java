package com.lg.microservice.cart.model.response;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class Email {

	@JsonProperty("label")
	private String label;
	
	@JsonProperty("id")
	private String id;
}
