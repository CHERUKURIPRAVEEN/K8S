package com.lg.microservice.cart.model.entity;

import java.util.HashMap;
import java.util.Map;

import com.lg.microservice.cart.model.response.ResponseData;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;

@Slf4j
public class ContentStack {

	private static ContentStack contentStack = new ContentStack();

	private static Map<String, Map<String, String>> keyContentListMap = new HashMap<String, Map<String, String>>();

	private static Map<String, ResponseEntity<ResponseData>>  keyContentResponseMap = new HashMap<String, ResponseEntity<ResponseData>>();

	private ContentStack() { }

	public static ContentStack getInstance() {
		return contentStack;
	}

	public static Map<String, Map<String, String>> getKeyContentListMap() {
		return keyContentListMap;
	}

	public static ResponseEntity<ResponseData> getKeyContentResponseMap(String key) {
		return keyContentResponseMap.get(key);
	}

	public static void updateGlobalMap(Map<String, Map<String, String>> inputMap) {
		keyContentListMap = inputMap;
	}

	public static void updateGlobalResponseMap(String key, ResponseEntity<ResponseData> result) {
		keyContentResponseMap.put(key, result);
	}

	public void emptyGlobalMap() {
		keyContentListMap.clear();
		keyContentResponseMap.clear();
	}
}
