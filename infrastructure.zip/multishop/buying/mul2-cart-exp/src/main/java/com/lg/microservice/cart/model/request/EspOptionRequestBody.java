package com.lg.microservice.cart.model.request;

public class EspOptionRequestBody {

}
