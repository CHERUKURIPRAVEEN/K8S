package com.lg.microservice.cart.model.response;

import java.util.List;
import lombok.Data;

@Data
public class CartItemsIdAndQuantityResponse {
  public String id;
  List<ItemIdAndQuantityResponse> items;
}
