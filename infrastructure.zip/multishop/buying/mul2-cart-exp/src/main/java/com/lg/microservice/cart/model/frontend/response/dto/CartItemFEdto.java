package com.lg.microservice.cart.model.frontend.response.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"cartItemId", "quantity", "status", "productInfo",
		"productActions", "cartItemOptions"})
@Data
public class CartItemFEdto {
	@JsonProperty("cartItemId")
	public String cartItemId;
	@JsonProperty("quantity")
	public Integer quantity;
	@JsonProperty("groupid")
	public String groupid;
	@JsonProperty("status")
	public StatusDto status;
	@JsonProperty("productInfo")
	public ProductInfoFEdto productInfo;
	@JsonProperty("productActions")
	public List<ProductActionFEdto> productActions = null;
	@JsonProperty("cartItemOptions")
	public List<CartItemOptionFEdto> cartItemOptions = null;
	@JsonProperty("serviceProducts")
	public List<ServiceProductDetailDto> serviceProducts = null;

}
