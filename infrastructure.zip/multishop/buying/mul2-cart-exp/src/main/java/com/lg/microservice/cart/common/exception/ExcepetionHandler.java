package com.lg.microservice.cart.common.exception;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.lg.microservice.cart.constant.Constants;
import com.lg.microservice.cart.util.MessageConstants;

@ControllerAdvice
public class ExcepetionHandler extends ResponseEntityExceptionHandler {
  
  
  @ExceptionHandler(CartIDNotFoundException.class)
  public ResponseEntity<Object> handleNotFoundExceptions(CartIDNotFoundException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      ResponseEntity<Object> entity = null;
      if(exception.getMessage()!=null) {
        response.setMessage(exception.getMessage());
        entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
        response.setStatusCode(HttpStatus.NOT_FOUND.value());
      }
      if(exception.getMessage()==null) {
        response.setMessage(MessageConstants.PASS_CART_ID_ERROR);
        entity = new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        response.setStatusCode(HttpStatus.BAD_REQUEST.value());
      }
      
      return entity;
  }

  @ExceptionHandler(MagentoValidationException.class)
  public ResponseEntity<Object> handleNotFoundExceptions(MagentoValidationException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      ResponseEntity<Object> entity = null;
      if(exception.getMessage()!=null) {
        response.setMessage(exception.getMessage());
        if(exception.getRedirectTo() != null){
            response.setRedirectTo(exception.getRedirectTo());
        }
        entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
        response.setStatusCode(HttpStatus.NOT_FOUND.value());
      }
      if(exception.getMessage()==null) {
        response.setMessage(MessageConstants.PASS_CART_ID_ERROR);
        entity = new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        response.setStatusCode(HttpStatus.BAD_REQUEST.value());
      }
      
      return entity;
  }

  @ExceptionHandler(MagentoInternalServerException.class)
  public ResponseEntity<Object> handleInternalServerExceptions(MagentoInternalServerException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      response.setMessage(MessageConstants.MAGENTO_INTERNAL_SERVER_ERROR);
      response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
      ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
      return entity;
  }

  
  @ExceptionHandler(FeignBadGatewayException.class)
  public ResponseEntity<Object> handleBadGatewayException(FeignBadGatewayException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      response.setMessage(MessageConstants.BAD_GATWAY_EXCEPTION_MESSAGE);
      response.setStatusCode(HttpStatus.BAD_GATEWAY.value());
      ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.BAD_GATEWAY);
      return entity;
  }
  
  @ExceptionHandler(FeignBadGatewayTimeoutException.class)
  public ResponseEntity<Object> handleBadGatewayTimeoutException(FeignBadGatewayTimeoutException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      response.setMessage(MessageConstants.BAD_GATWAY_TIMEOUT_EXCEPTION_MESSAGE);
      response.setStatusCode(HttpStatus.GATEWAY_TIMEOUT.value());
      ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.GATEWAY_TIMEOUT);
      return entity;
  }
  
  @ExceptionHandler(ApplicationInternalServerException.class)
  public ResponseEntity<Object> handleInternalServerExceptions(ApplicationInternalServerException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      response.setMessage(MessageConstants.APPLICATION_INTERNAL_SERVER_ERROR);
      response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
      ResponseEntity<Object> entity = new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
      return entity;
  }
  
  @ExceptionHandler(TokenNotFoundException.class)
  public ResponseEntity<Object> handleNotFoundExceptions(TokenNotFoundException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      ResponseEntity<Object> entity = null;
      if(exception.getMessage()!=null) {
        response.setMessage(exception.getMessage());
        entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
        response.setStatusCode(HttpStatus.NOT_FOUND.value());
      }
      if(exception.getMessage()==null) {
        response.setMessage(MessageConstants.PASS_TOKEN_ERROR);
        entity = new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
        response.setStatusCode(HttpStatus.BAD_REQUEST.value());
      }
      
      return entity;
  }
  
  @ExceptionHandler(StoreConfigCallException.class)
  public ResponseEntity<Object> handleStoreConfigCallException(StoreConfigCallException exception, WebRequest webRequest) {
      ExceptionResponse response = new ExceptionResponse();
      ResponseEntity<Object> entity = null;
      if(exception.getMessage()!=null) {
        response.setMessage(exception.getMessage());
        entity = new ResponseEntity<>(response,HttpStatus.INTERNAL_SERVER_ERROR);
        response.setStatusCode(HttpStatus.INTERNAL_SERVER_ERROR.value());
      }
      return entity;
  }
  
  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      MethodArgumentNotValidException ex, HttpHeaders headers, 
      HttpStatus status, WebRequest request) {

      Map<String, Object> body = new LinkedHashMap<>();
      body.put("status", status.value());

      List<String> errors = ex.getBindingResult()
              .getFieldErrors()
              .stream()
              .map(x -> x.getDefaultMessage())
              .collect(Collectors.toList());

      body.put("errors", errors);

      return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
  }
  
	@ExceptionHandler(SSOValidationFailed.class)
	public ResponseEntity<Object> handleInternalServerExceptions(SSOValidationFailed exception, WebRequest webRequest) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage(Constants.SSO_VALIDATION);
		response.setStatusCode(HttpStatus.BAD_REQUEST.value());
		ResponseEntity<Object> entity = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		return entity;
	}

	@ExceptionHandler(InvalidZipcodeException.class)
	public ResponseEntity<Object> handleInternalServerExceptions(InvalidZipcodeException exception,
			WebRequest webRequest) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage(Constants.ZIPCODE_NOT_FOUND);
		response.setStatusCode(HttpStatus.BAD_REQUEST.value());
		ResponseEntity<Object> entity = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		return entity;
	}

	@ExceptionHandler(LatLngNotFoundException.class)
	public ResponseEntity<Object> handleInternalServerExceptions(LatLngNotFoundException exception,
			WebRequest webRequest) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage(Constants.INVALID_LATLNG);
		response.setStatusCode(HttpStatus.BAD_REQUEST.value());
		ResponseEntity<Object> entity = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		return entity;
	}


	@ExceptionHandler(InvalidDataException.class)
	public ResponseEntity<Object> handleInternalServerExceptions(InvalidDataException exception,
			WebRequest webRequest) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage(Constants.INVALID_DATA);
		response.setStatusCode(HttpStatus.BAD_REQUEST.value());
		ResponseEntity<Object> entity = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		return entity;
	}
	

	@ExceptionHandler(InvalidResponseException.class)
	public ResponseEntity<Object> handleInternalServerExceptions(InvalidResponseException exception,
			WebRequest webRequest) {
		ExceptionResponse response = new ExceptionResponse();
		response.setMessage(Constants.NO_VALID_RESPONSE);
		response.setStatusCode(HttpStatus.BAD_REQUEST.value());
		ResponseEntity<Object> entity = new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
		return entity;
	}


    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<Object> handleNotFoundExceptions(BadRequestException exception, WebRequest webRequest) {
        ExceptionResponse response = new ExceptionResponse();
        ResponseEntity<Object> entity = null;
        if(exception.getMessage()!=null) {
            response.setMessage(exception.getMessage());
            entity = new ResponseEntity<>(response,HttpStatus.NOT_FOUND);
            response.setStatusCode(HttpStatus.BAD_REQUEST.value());
        }
        if(exception.getMessage()==null) {
            response.setMessage(MessageConstants.PASS_CART_ID_ERROR);
            entity = new ResponseEntity<>(response,HttpStatus.BAD_REQUEST);
            response.setStatusCode(HttpStatus.BAD_REQUEST.value());
        }

        return entity;
    }

    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<Object> handleUnauthorizedException(
            UnauthorizedException exception, WebRequest webRequest) {
        ExceptionResponse response = new ExceptionResponse();
        response.setMessage(MessageConstants.UNAUTHORIZED_ERROR_MESSAGE);
        ResponseEntity<Object> entity = new ResponseEntity<>(response,
                HttpStatus.UNAUTHORIZED);

        return entity;
    }
}

