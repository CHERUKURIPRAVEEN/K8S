package com.lg.microservice.cart.model.frontend.response;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.lg.microservice.cart.model.dto.magento.MagentoError;
import com.lg.microservice.cart.model.frontend.response.dto.ShipmentItemFEDto;
import com.lg.microservice.cart.model.frontend.response.dto.StatusDto;
import com.lg.microservice.cart.model.frontend.response.dto.TotalOrderSavingDto;

import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"cartId",
"shipmentItems",
"status"
})

@Data
public class CartItemFEResponse {

@JsonProperty("cartId")
public String cartId;
@JsonProperty("shipmentItems")
public List<ShipmentItemFEDto> shipmentItems = null;
@JsonProperty("status")
public StatusDto status;

@JsonProperty("statusCode")
private Integer statusCode;

@JsonProperty("errors")
private List<MagentoError> errors;

@JsonProperty("totalOrderSaving")
private TotalOrderSavingDto totalOrderSavingsDto;

}