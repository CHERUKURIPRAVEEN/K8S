package com.lg.microservice.cart.common.config.AopLogging.properties;

import com.lg.microservice.cart.constant.LogConstants;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(
    prefix = "trace-log-aspect.controller"
)
@Data
public class ControllerProperties {
    private boolean enabled = false;
    private String prefix = LogConstants.CTR_PREFIX;
    private String exclude;
}
