package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class HandyRequest {
	@NotBlank
	private String token;
	@NotBlank
	private String sku;
	private String cartId;
	private String store;

	public static HandyRequest of(String token, String sku, String cartId, String store) {
		Objects.requireNonNull(token);
		Objects.requireNonNull(sku, store);
		return new HandyRequest(token, sku, cartId, store);
	}

}
