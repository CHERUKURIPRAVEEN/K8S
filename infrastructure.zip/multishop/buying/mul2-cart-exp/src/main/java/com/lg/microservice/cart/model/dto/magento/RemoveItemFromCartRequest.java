package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class RemoveItemFromCartRequest {

	@NotBlank
	private String cartId;

	@NotBlank
	private String store;

	@NotBlank
	private String cartItemId;

	private String token;

	public static RemoveItemFromCartRequest of(String cartId, String store, String cartItemId, String token) {
		Objects.requireNonNull(cartId, store);
		Objects.requireNonNull(cartItemId);

		return new RemoveItemFromCartRequest(cartId, store, cartItemId, token);
	}
}
