package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class CategoryPurchaseLimit {

        @JsonProperty("categoryId")
        private Integer categoryId;

        @JsonProperty("categoryName")
        private String categoryName;

        @JsonProperty("description")
        private String description;

        @JsonProperty("is_usable")
        private Integer is_usable;

        @JsonProperty("purchaseLimits")
        private Integer purchaseLimits;

        @JsonProperty("remainingLimit")
        private Integer remainingLimit;

}
