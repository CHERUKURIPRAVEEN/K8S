package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)

@Data
public class MaxPriceDto {

	@JsonProperty("final_price")
	public FinalPriceDto final_price;
	
	@JsonProperty("regular_price")
    public RegularPriceDto regular_price;
	

}
