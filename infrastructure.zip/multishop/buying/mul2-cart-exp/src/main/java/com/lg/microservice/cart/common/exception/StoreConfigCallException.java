package com.lg.microservice.cart.common.exception;

public class StoreConfigCallException extends RuntimeException{
private String message;
  
  public StoreConfigCallException (String message) {
    this.message=message;
  }
  public StoreConfigCallException () {
      }
}
