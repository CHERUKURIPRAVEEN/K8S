package com.lg.microservice.cart.model.frontend.response.dto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"icon",
"label"
})
public class FeatureFEdto {

@JsonProperty("icon")
public String icon;
@JsonProperty("label")
public String label;

}
