package com.lg.microservice.cart.model.dto.magento;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class DSRequest {
	@NotBlank
	private String token;
	@NotBlank
	private String itemId;
	private String cartId;
	private String store;

	public static DSRequest of(String token, String itemId, String cartId, String store) {
		Objects.requireNonNull(token);
		Objects.requireNonNull(itemId, store);
		return new DSRequest(token, itemId, cartId, store);
	}
}
