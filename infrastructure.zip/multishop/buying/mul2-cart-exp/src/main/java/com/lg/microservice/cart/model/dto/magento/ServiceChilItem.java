package com.lg.microservice.cart.model.dto.magento;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ServiceChilItem {

	@JsonProperty("service_type")
	public String service_type;
	@JsonProperty("child_item_id")
	public String child_item_id;
}
