package com.lg.microservice.cart.model.response;

import lombok.Data;

@Data
public class ItemIdAndQuantityResponse {
  public String id;
  public Integer quantity;
}
