package com.lg.microservice.cart.model.frontend.response.dto;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"isValid",
"title",
"message",
})
@Data
public class StatusDto {

@JsonProperty("isValid")
public Boolean isValid;

@JsonProperty("message")
public String message;

@JsonProperty("type")
public String type;

  public StatusDto(boolean isValid,String message){
    this.isValid=isValid;    
    this.message=message;
  }

  public StatusDto(boolean isValid,String type,String message){
    this.isValid=isValid;
    this.type=type;
    this.message=message;
  }
}
