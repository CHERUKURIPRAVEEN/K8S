package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class FrequentlyAskedQuestions {
	
	@JsonProperty("returnPolicy")
	private ReturnPolicy returnPolicy;
	
	@JsonProperty("email")
	private Email email;
	
	@JsonProperty("customerService")
	private CustomerService customerService;
	
	@JsonProperty("workingHrs")
	private WorkingHours workingHrs;
	
	@JsonProperty("holidays")
	private Holidays holidays;
	
	@JsonProperty("banner")
	private Banner banner;

}

