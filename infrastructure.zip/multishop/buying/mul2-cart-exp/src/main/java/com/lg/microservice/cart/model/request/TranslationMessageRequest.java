package com.lg.microservice.cart.model.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.List;

@Getter
@Setter
@Data
@NotNull
public class TranslationMessageRequest {

    String stack;

    List<String> keyList;

    String locale;

}
