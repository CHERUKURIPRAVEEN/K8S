package com.lg.microservice.cart.model.request;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class RemoveCartItemBody {  

  @JsonProperty("cartItemId")
  @Schema(description = "cart ItemId should not be blank")
  private String cartItemId;

  @JsonProperty("action")
  @Schema(description = "action is optional")
  private String action;

}
