package com.lg.microservice.cart.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class CustomerService {

	@JsonProperty("label")
	private String label;

	@JsonProperty("phone")
	private String phone;

}
