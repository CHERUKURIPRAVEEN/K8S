package com.lg.microservice.cart.model.request;

import java.util.Objects;

import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class CartItemRequest {

    @NotBlank
    private String cartId;
    
    private String token;
    
    private String store;

    public static CartItemRequest of(String cartId, String token, String store) {
      Objects.requireNonNull(cartId,store);
      Objects.requireNonNull(token);
      return new CartItemRequest(cartId,token,store);
  }


}
