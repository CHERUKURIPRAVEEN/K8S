package com.lg.microservice.cart.constant;

import lombok.experimental.UtilityClass;

@UtilityClass
public class HttpHeaderConstants {
    public static final String ACCESS_CONTROL_ALLOW_ORIGIN = "Access-Control-Allow-Origin";
    public static final String ACCESS_CONTROL_ALLOW_CREDENTIALS = "Access-Control-Allow-Credentials";
    public static final String CACHE_CONTROL = "Cache-Control";
    public static final String CACHE_CONTROL_VAL = "no-cache, no-store, max-age=0, must-revalidate";
    public static final String PRAGMA = "Pragma";
    public static final String PRAGMA_VAL = "no-cache";
    public static final String EXPIRES = "Expires";
    public static final int EXPIRES_VAL = -1;
    public static final String X_SESSION_ID = "X-Session-Id";
    public static final String CONTENT_TYPE_KEY = "Content-Type";
    public static final String CONTENT_LENGTH = "Content-Length";
    public static final String CONTENT_TYPE_APPLICATION_JSON = "application/json";
    public static final String CHARSET_UTF8 = "charset=UTF-8";
    public static final String X_API_KEY = "x-apikey";
    public static final String ACCEPT = "Accept";
    public static final String X_TABLEAU_AUTH = "X-Tableau-Auth";
    public static final String X_CORRELATION_ID = "X-Correlation-Id";
}
